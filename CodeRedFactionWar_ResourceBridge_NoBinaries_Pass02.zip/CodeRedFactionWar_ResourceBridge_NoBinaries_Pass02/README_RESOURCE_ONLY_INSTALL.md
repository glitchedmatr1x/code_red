# Code RED Faction War Resource Bridge — No Binaries Pass 02

This package removes the RedHook runtime DLLs, winmm proxy DLL, Visual Studio project files, and C++ plugin shell from the previous pass.

It contains only editable/resource-side bridge files:

- `.tr` AI rule bridge files
- `.pop` population profile bridge files
- `.traffic` traffic/road pressure bridge files
- `.json` faction/node data
- `.ini` editable world-state bridge data
- `.diff` merge previews
- `.md/.txt` notes and validation
- one Python generator script used to rebuild the bridge files from the data

## Why this clean package exists

The prior package included a RedHook runtime folder with DLL files, including a `winmm.dll` proxy loader. Even though that is normal for many game mod loaders, security filters often flag DLL proxy/injection-style mod loaders because the same technique can be used by malware.

This archive avoids that by shipping no compiled binaries.

## What to use first

Start with:

`WorldResourceBridge/README_PASS02_QUICKSTART.md`

The current bridge is not yet a drop-in finished RPF installer. It is the generated resource patch lane for Code RED to install into tune/content RPFs in the next pass.

## Intended Code RED targets

- `tune_d11generic.rpf` → `root/tune/ai/game_main.tr`
- optional generated include: `root/tune/ai/code_red_factionwar_world.tr`
- later: population and traffic bridge files

