# Code RED Main Launcher Unification Pass

Date: 2026-05-03

## Goal

Resolve the two-main collision without breaking old shortcuts.

## Finding

`main.py` was the stronger canonical launcher because it already created runtime folders, wrapped the workbench launch in a callable `main()` function, returned process status, and wrote crash logs.

`run_workbench.py` was the weaker launcher because it executed everything at import time, had no crash logging, had no return-code wrapper, and started the whole workbench inside MP Companion when that folder existed.

The useful behavior from `run_workbench.py` was its MP Companion workspace discovery. That is now available as an explicit compatibility flag in `main.py`.

## Updated

- `main.py`
  - Added CLI parsing.
  - Added `--workspace`.
  - Added `--legacy-companion-workspace`.
  - Added `--title`.
  - Added `--dry-run` for headless launch tests.
  - Kept crash logging and runtime folder creation.
  - Kept repo root as default startup workspace.

- `run_workbench.py`
  - Replaced duplicate loader logic with a compatibility wrapper around `main.py`.
  - Preserves old `Code RED Resource Workbench` title.
  - Preserves old MP Companion workspace behavior only when this wrapper is called.

## Test Commands

```bat
py -3 -m py_compile main.py run_workbench.py python_workbench.py
py -3 main.py --dry-run
py -3 run_workbench.py --dry-run
```

## Result

`Run_Code_RED.bat` still launches `main.py` and now has the cleaner canonical behavior.

Old `run_workbench.py` shortcuts still work, but no longer duplicate the main loader.
