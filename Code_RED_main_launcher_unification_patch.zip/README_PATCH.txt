Code RED Main Launcher Unification Patch
=======================================

Copy these files into the root of your Code_RED folder:

- main.py
- run_workbench.py
- logs/CodeRED_Main_Launcher_Unification_Pass_2026-05-03.md

What changed:
- main.py is now the canonical launcher.
- main.py supports --workspace, --legacy-companion-workspace, --title, and --dry-run.
- run_workbench.py is now a compatibility wrapper around main.py.
- Run_Code_RED.bat can remain as-is because it already calls main.py.

Test from the Code_RED root:

py -3 -m py_compile main.py run_workbench.py python_workbench.py
py -3 main.py --dry-run
py -3 run_workbench.py --dry-run
