#!/usr/bin/env python3
"""Code RED regression guard.

Compares the current Code RED tree against a checkpoint zip/folder and reports
what changed, what was intentionally removed, and whether critical lanes still
have their files/proof. This is designed for the checkpoint-zip workflow so
older salvage does not silently get pulled back into the app.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import sys
import tempfile
import zipfile
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Iterable

VERSION = "1.0.0-regression-guard"

SKIP_DIRS = {".git", ".hg", ".svn", "__pycache__", ".pytest_cache", ".mypy_cache", ".vs", "build", "dist", "node_modules"}
SKIP_SUFFIXES = {".pyc", ".pyo", ".pdb", ".obj", ".pch", ".ipdb", ".iobj", ".vc.db", ".vsidx"}
TEXT_SUFFIXES = {".py", ".txt", ".md", ".csv", ".json", ".ini", ".xml", ".bat", ".cmd", ".ps1", ".c", ".cpp", ".h", ".hpp"}

# Files intentionally removed because their behavior was fully salvaged.
INTENTIONAL_OBSOLETE = {
    "run_workbench.py": "Fully salvaged into main.py; keeping it risks reintroducing MP Companion-first startup.",
}

CRITICAL_PATHS = [
    "main.py",
    "python_workbench.py",
    "Run_Code_RED.bat",
    "codered_app/paths.py",
    "codered_app/launcher_registry.py",
    "tools/codered_one_app_status.py",
    "tools/codered_file_io_validation.py",
    "tools/codered_script_workshop_decode.py",
    "tools/codered_ai_trainer_validation.py",
    "tools/codered_archive_lane_validation.py",
    "tools/codered_native_database.py",
    "tools/codered_native_bridge_generation.py",
    "tools/codered_script_compile_validation.py",
    "tools/codered_terrainboundres_validation.py",
    "tools/codered_codex_modelxml_validation.py",
    "tools/codered_ai_menu_bridge_integration.py",
    "tools/codered_regression_guard.py",
    "data/codered/actor_enum_map.csv",
    "data/codered/ai_behavior_actions.csv",
    "data/codered/npc_roster.txt",
    "research/CodeRED_RESEARCH_MANIFEST.csv",
]

@dataclass
class FileInfo:
    rel: str
    size: int
    sha1: str
    suffix: str

@dataclass
class RegressionReport:
    version: str
    generated_utc: str
    root: str
    baseline: str
    baseline_found: bool
    current_files: int
    baseline_files: int
    added: list[str]
    removed: list[str]
    changed: list[str]
    intentional_obsolete_removed: dict[str, str]
    unexpected_removed: list[str]
    critical_missing: list[str]
    critical_present: list[str]
    obsolete_present: dict[str, str]
    source_dirs: list[str]
    source_files: int
    source_decode_ok: int
    source_decode_failed: int
    source_decode_failures: list[str]
    ok: bool
    notes: list[str] = field(default_factory=list)


def utc_now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z")


def should_skip(path: Path, root: Path) -> bool:
    rel_parts = path.relative_to(root).parts
    if any(part in SKIP_DIRS for part in rel_parts):
        return True
    name = path.name.lower()
    if name.endswith(".vc.db") or name.endswith(".browse.vc.db"):
        return True
    if path.suffix.lower() in SKIP_SUFFIXES:
        return True
    return False


def inventory(root: Path) -> dict[str, FileInfo]:
    data: dict[str, FileInfo] = {}
    for path in root.rglob("*"):
        if path.is_dir() or should_skip(path, root):
            continue
        try:
            payload = path.read_bytes()
        except Exception:
            continue
        rel = path.relative_to(root).as_posix()
        data[rel] = FileInfo(rel=rel, size=len(payload), sha1=hashlib.sha1(payload).hexdigest(), suffix=path.suffix.lower())
    return data


def extract_zip_to_temp(path: Path) -> tempfile.TemporaryDirectory:
    tmp = tempfile.TemporaryDirectory(prefix="codered_regression_baseline_")
    with zipfile.ZipFile(path) as zf:
        zf.extractall(tmp.name)
    return tmp


def resolve_baseline(root: Path, baseline: str | None) -> tuple[Path | None, tempfile.TemporaryDirectory | None, list[str]]:
    notes: list[str] = []
    candidates: list[Path] = []
    if baseline:
        candidates.append(Path(baseline))
    candidates.extend([
        root / "Code_RED.zip",
        root / "imports" / "Code_RED.zip",
        root.parent / "Code_RED.zip",
    ])
    for candidate in candidates:
        if not candidate.exists():
            continue
        if candidate.is_file() and candidate.suffix.lower() == ".zip":
            tmp = extract_zip_to_temp(candidate)
            notes.append(f"Baseline zip extracted: {candidate}")
            return Path(tmp.name), tmp, notes
        if candidate.is_dir():
            notes.append(f"Baseline folder used: {candidate}")
            return candidate, None, notes
    return None, None, notes


def detect_source_dirs(root: Path) -> list[Path]:
    names = {"src", "source", "sources", "Source", "SRC"}
    out: list[Path] = []
    for path in root.rglob("*"):
        if path.is_dir() and path.name in names and not should_skip(path, root):
            out.append(path)
    return sorted(out, key=lambda p: p.as_posix())


def decode_source_files(source_dirs: Iterable[Path], root: Path, limit: int = 2000) -> tuple[int, int, list[str]]:
    total = 0
    ok = 0
    failures: list[str] = []
    for source_dir in source_dirs:
        for path in source_dir.rglob("*"):
            if total >= limit:
                return total, ok, failures
            if path.is_dir() or should_skip(path, root):
                continue
            if path.suffix.lower() not in TEXT_SUFFIXES:
                continue
            total += 1
            try:
                path.read_text(encoding="utf-8")
                ok += 1
            except UnicodeDecodeError:
                try:
                    path.read_text(encoding="latin-1")
                    ok += 1
                except Exception as exc:
                    failures.append(f"{path.relative_to(root).as_posix()}: {exc}")
            except Exception as exc:
                failures.append(f"{path.relative_to(root).as_posix()}: {exc}")
    return total, ok, failures


def compare(root: Path, baseline_arg: str | None) -> RegressionReport:
    baseline_root, tmp, notes = resolve_baseline(root, baseline_arg)
    current = inventory(root)
    baseline = inventory(baseline_root) if baseline_root is not None else {}
    added = sorted(set(current) - set(baseline)) if baseline else sorted(current)
    removed = sorted(set(baseline) - set(current)) if baseline else []
    changed = sorted(rel for rel in set(current) & set(baseline) if current[rel].sha1 != baseline[rel].sha1) if baseline else []

    intentional_removed = {rel: INTENTIONAL_OBSOLETE[rel] for rel in removed if rel in INTENTIONAL_OBSOLETE}
    unexpected_removed = [rel for rel in removed if rel not in INTENTIONAL_OBSOLETE]
    critical_missing = [rel for rel in CRITICAL_PATHS if rel not in current]
    critical_present = [rel for rel in CRITICAL_PATHS if rel in current]
    obsolete_present = {rel: reason for rel, reason in INTENTIONAL_OBSOLETE.items() if rel in current}
    src_dirs = detect_source_dirs(root)
    source_total, source_ok, source_failures = decode_source_files(src_dirs, root)

    ok = True
    if critical_missing:
        ok = False
    if unexpected_removed:
        ok = False
    if obsolete_present:
        ok = False
    if source_failures:
        ok = False
    if baseline_root is None:
        notes.append("No baseline checkpoint zip/folder found; regression diff was limited to critical/obsolete/source checks.")
    if tmp is not None:
        tmp.cleanup()

    return RegressionReport(
        version=VERSION,
        generated_utc=utc_now(),
        root=str(root),
        baseline=str(baseline_root) if baseline_root else "",
        baseline_found=baseline_root is not None,
        current_files=len(current),
        baseline_files=len(baseline),
        added=added,
        removed=removed,
        changed=changed,
        intentional_obsolete_removed= intentional_removed,
        unexpected_removed=unexpected_removed,
        critical_missing=critical_missing,
        critical_present=critical_present,
        obsolete_present=obsolete_present,
        source_dirs=[p.relative_to(root).as_posix() for p in src_dirs],
        source_files=source_total,
        source_decode_ok=source_ok,
        source_decode_failed=len(source_failures),
        source_decode_failures=source_failures[:100],
        ok=ok,
        notes=notes,
    )


def write_csv_manifest(report: RegressionReport, out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for rel in report.added:
        rows.append({"status": "added", "path": rel, "note": ""})
    for rel in report.changed:
        rows.append({"status": "changed", "path": rel, "note": ""})
    for rel in report.removed:
        rows.append({"status": "removed", "path": rel, "note": report.intentional_obsolete_removed.get(rel, "unexpected")})
    with out_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["status", "path", "note"])
        writer.writeheader()
        writer.writerows(rows)


def to_markdown(report: RegressionReport) -> str:
    lines = [
        "# Code RED Regression Guard Report",
        "",
        f"Generated: `{report.generated_utc}`",
        f"Result: **{'PASS' if report.ok else 'FAIL'}**",
        f"Root: `{report.root}`",
        f"Baseline found: `{report.baseline_found}`",
        f"Baseline: `{report.baseline}`",
        "",
        "## Summary",
        "",
        f"- Current files: {report.current_files}",
        f"- Baseline files: {report.baseline_files}",
        f"- Added: {len(report.added)}",
        f"- Changed: {len(report.changed)}",
        f"- Removed: {len(report.removed)}",
        f"- Intentional obsolete removals: {len(report.intentional_obsolete_removed)}",
        f"- Unexpected removals: {len(report.unexpected_removed)}",
        f"- Critical missing: {len(report.critical_missing)}",
        f"- Obsolete present: {len(report.obsolete_present)}",
        f"- Source dirs: {len(report.source_dirs)}",
        f"- Source files decoded: {report.source_decode_ok}/{report.source_files}",
        "",
        "## Intentional obsolete removals",
        "",
    ]
    if report.intentional_obsolete_removed:
        for rel, reason in report.intentional_obsolete_removed.items():
            lines.append(f"- `{rel}` - {reason}")
    else:
        lines.append("- None")
    lines.extend(["", "## Problems", ""])
    if not (report.critical_missing or report.unexpected_removed or report.obsolete_present or report.source_decode_failures):
        lines.append("- None")
    for rel in report.critical_missing:
        lines.append(f"- Critical missing: `{rel}`")
    for rel in report.unexpected_removed[:80]:
        lines.append(f"- Unexpected removal: `{rel}`")
    for rel, reason in report.obsolete_present.items():
        lines.append(f"- Obsolete file still present: `{rel}` - {reason}")
    for failure in report.source_decode_failures[:40]:
        lines.append(f"- Source decode failed: `{failure}`")
    lines.extend(["", "## Source directories", ""])
    if report.source_dirs:
        for rel in report.source_dirs[:80]:
            lines.append(f"- `{rel}`")
    else:
        lines.append("- None found in this local package. If source was added to GitHub, pull or place it into this package before running the guard locally.")
    lines.extend(["", "## Notes", ""])
    for note in report.notes:
        lines.append(f"- {note}")
    return "\n".join(lines) + "\n"


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Compare Code RED against a checkpoint zip/folder and flag regressions.")
    parser.add_argument("--root", default=".", help="Code RED root folder")
    parser.add_argument("--baseline", default=None, help="Baseline zip or folder. Defaults to Code_RED.zip in root/imports/parent.")
    parser.add_argument("--out-json", default="logs/CodeRED_Regression_Guard_Report.json")
    parser.add_argument("--out-md", default="logs/CodeRED_Regression_Guard_Report.md")
    parser.add_argument("--out-csv", default="data/codered/regression_guard_manifest.csv")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    root = Path(args.root).resolve()
    report = compare(root, args.baseline)
    json_path = (root / args.out_json).resolve() if not Path(args.out_json).is_absolute() else Path(args.out_json)
    md_path = (root / args.out_md).resolve() if not Path(args.out_md).is_absolute() else Path(args.out_md)
    csv_path = (root / args.out_csv).resolve() if not Path(args.out_csv).is_absolute() else Path(args.out_csv)
    json_path.parent.mkdir(parents=True, exist_ok=True)
    md_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(asdict(report), indent=2), encoding="utf-8")
    md_path.write_text(to_markdown(report), encoding="utf-8")
    write_csv_manifest(report, csv_path)
    print(to_markdown(report))
    return 0 if report.ok else 2

if __name__ == "__main__":
    raise SystemExit(main())
