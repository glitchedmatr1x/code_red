#!/usr/bin/env python3
"""Generate selected Code RED native bridge wrappers.

This pass deliberately does not wire every discovered native into an ASI. It merges
Code RED's generated native database with ScriptHookRDR's SDK native hashes, selects
small proof-friendly profiles, and writes C++ wrapper prep files plus proof reports.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Iterable, Sequence

VERSION = "1.0.0-native-bridge-generation-pass"

DEFAULT_PROFILE = "ai_trainer_core"
DEFAULT_PROFILES = {
    "ai_trainer_core": [
        "GET_PLAYER_ACTOR",
        "IS_ACTOR_VALID",
        "IS_ACTOR_ALIVE",
        "FIND_NAMED_LAYOUT",
        "CREATE_LAYOUT",
        "CREATE_ACTOR_IN_LAYOUT",
        "GET_POSITION",
        "TELEPORT_ACTOR",
        "SET_ACTOR_HEADING",
        "TASK_CLEAR",
        "TASK_STAND_STILL",
        "TASK_WANDER",
        "TASK_FOLLOW_ACTOR",
        "TASK_KILL_CHAR",
        "AI_IS_HOSTILE_OR_ENEMY",
        "SET_ACTOR_FACTION",
        "GET_ACTOR_FACTION",
        "GIVE_WEAPON_TO_ACTOR",
        "TASK_MOUNT",
        "TASK_DISMOUNT",
        "GET_MOUNT",
        "GET_VEHICLE",
        "START_VEHICLE",
        "STOP_VEHICLE",
        "TASK_VEHICLE_LEAVE",
        "RELEASE_LAYOUT_REF",
    ],
    "vehicle_probe": [
        "GET_PLAYER_ACTOR",
        "IS_ACTOR_VALID",
        "CREATE_LAYOUT",
        "CREATE_ACTOR_IN_LAYOUT",
        "GET_VEHICLE",
        "START_VEHICLE",
        "STOP_VEHICLE",
        "IS_ACTOR_VEHICLE",
        "IS_ACTOR_DRIVING_VEHICLE",
        "IS_ACTOR_RIDING_VEHICLE",
        "GET_ACTOR_IN_VEHICLE_SEAT",
        "ENABLE_VEHICLE_SEAT",
        "TASK_VEHICLE_LEAVE",
    ],
    "faction_combat_probe": [
        "GET_PLAYER_ACTOR",
        "IS_ACTOR_VALID",
        "TASK_CLEAR",
        "TASK_FOLLOW_ACTOR",
        "TASK_KILL_CHAR",
        "AI_IS_HOSTILE_OR_ENEMY",
        "SET_ACTOR_FACTION",
        "GET_ACTOR_FACTION",
        "SET_FACTION_STATUS_TO_INDIVIDUAL_ACTOR",
        "CLEAR_FACTION_STATUS_TO_INDIVIDUAL_ACTOR",
        "MEMORY_CONSIDER_AS_ENEMY",
        "MEMORY_CONSIDER_ACCORDING_TO_FACTION",
    ],
}

SDK_NATIVE_RE = re.compile(
    r"static\s+(?P<return_type>[^\n{};]+?)\s+"
    r"(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*\((?P<params>[^)]*)\)\s*\{"
    r"(?P<body>[^{}]*(?:\{[^{}]*\}[^{}]*)*)\}\s*//\s*(?P<hash>0x[0-9A-Fa-f]+)",
    re.MULTILINE,
)
INVOKE_HASH_RE = re.compile(r"invoke\s*<[^>]+>\s*\(\s*(0x[0-9A-Fa-f]+)")

@dataclass
class NativeSdkEntry:
    name: str
    hash: str
    return_type: str
    params: list[str]
    source: str
    line: int

@dataclass
class BridgeEntry:
    name: str
    hash: str
    category: str
    return_type: str
    params: list[str]
    db_return_type: str
    db_params: list[str]
    sdk_line: int
    db_line: int
    status: str
    warnings: list[str]


def utc_now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z")


def split_params(params: str) -> list[str]:
    clean = params.strip()
    if not clean or clean == "void":
        return []
    parts: list[str] = []
    depth = 0
    current = []
    for ch in clean:
        if ch == "<":
            depth += 1
        elif ch == ">" and depth:
            depth -= 1
        if ch == "," and depth == 0:
            part = "".join(current).strip()
            if part:
                parts.append(part)
            current = []
            continue
        current.append(ch)
    part = "".join(current).strip()
    if part:
        parts.append(part)
    return parts


def safe_identifier(name: str) -> str:
    ident = re.sub(r"[^A-Za-z0-9_]", "_", name.upper())
    if not re.match(r"[A-Za-z_]", ident):
        ident = "NATIVE_" + ident
    return "CR_NATIVE_" + ident


def parse_sdk_natives(path: Path) -> dict[str, NativeSdkEntry]:
    text = path.read_text(encoding="utf-8", errors="ignore")
    entries: dict[str, NativeSdkEntry] = {}
    for match in SDK_NATIVE_RE.finditer(text):
        name = match.group("name")
        hash_value = match.group("hash").upper().replace("X", "x")
        body_hash = INVOKE_HASH_RE.search(match.group("body"))
        if body_hash:
            hash_value = body_hash.group(1).upper().replace("X", "x")
        line = text.count("\n", 0, match.start()) + 1
        # Keep the first overload as the stable bridge default; overloads are still
        # detectable in the SDK source if a later pass needs profile-specific params.
        entries.setdefault(
            name,
            NativeSdkEntry(
                name=name,
                hash=hash_value,
                return_type=" ".join(match.group("return_type").split()),
                params=split_params(match.group("params")),
                source=str(path),
                line=line,
            ),
        )
    return entries


def load_native_database(path: Path) -> dict[str, dict]:
    if not path.exists():
        return {}
    data = json.loads(path.read_text(encoding="utf-8"))
    records = data.get("records", []) if isinstance(data, dict) else []
    out: dict[str, dict] = {}
    for record in records:
        name = str(record.get("name", "")).strip()
        if name and name not in out:
            out[name] = record
    return out


def select_profile_names(root: Path, profile: str, extra: Sequence[str]) -> list[str]:
    profile_path = root / "data" / "codered" / "native_bridge_profiles.json"
    profiles = dict(DEFAULT_PROFILES)
    if profile_path.exists():
        try:
            data = json.loads(profile_path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                for key, value in data.items():
                    if isinstance(value, list):
                        profiles[key] = [str(item).strip() for item in value if str(item).strip()]
        except Exception:
            pass
    selected = list(profiles.get(profile, profiles[DEFAULT_PROFILE]))
    selected.extend(extra)
    # Preserve order while removing duplicates.
    seen: set[str] = set()
    ordered: list[str] = []
    for name in selected:
        clean = name.strip()
        if clean and clean not in seen:
            seen.add(clean)
            ordered.append(clean)
    return ordered


def build_entries(root: Path, profile: str, extra: Sequence[str]) -> tuple[list[BridgeEntry], dict]:
    db_path = root / "data" / "codered" / "native_database.json"
    sdk_candidates = [
        root / "data" / "ScriptHookRDR" / "sdk" / "inc" / "natives.h",
        root / "research" / "menu resources" / "natives.h",
    ]
    sdk_path = next((p for p in sdk_candidates if p.exists()), sdk_candidates[0])
    db = load_native_database(db_path)
    sdk = parse_sdk_natives(sdk_path) if sdk_path.exists() else {}
    selected = select_profile_names(root, profile, extra)
    entries: list[BridgeEntry] = []
    for name in selected:
        db_rec = db.get(name, {})
        sdk_rec = sdk.get(name)
        warnings: list[str] = []
        if not db_rec:
            warnings.append("missing_from_native_database")
        if not sdk_rec:
            warnings.append("missing_from_scripthook_sdk_hash_source")
        db_params = [str(item) for item in db_rec.get("params", [])] if db_rec else []
        sdk_params = sdk_rec.params if sdk_rec else []
        if db_params and sdk_params and len(db_params) != len(sdk_params):
            warnings.append(f"param_count_diff_db_{len(db_params)}_sdk_{len(sdk_params)}")
        status = "ready" if sdk_rec and not any(w.startswith("missing") for w in warnings) else "partial"
        entries.append(
            BridgeEntry(
                name=name,
                hash=sdk_rec.hash if sdk_rec else str(db_rec.get("declared_hash", "")),
                category=str(db_rec.get("category", "uncategorized")) if db_rec else "uncategorized",
                return_type=sdk_rec.return_type if sdk_rec else str(db_rec.get("return_type", "void")),
                params=sdk_params,
                db_return_type=str(db_rec.get("return_type", "")) if db_rec else "",
                db_params=db_params,
                sdk_line=sdk_rec.line if sdk_rec else 0,
                db_line=int(db_rec.get("line") or 0) if db_rec else 0,
                status=status,
                warnings=warnings,
            )
        )
    meta = {"db_path": str(db_path), "sdk_path": str(sdk_path), "selected": selected, "sdk_count": len(sdk), "db_count": len(db)}
    return entries, meta


def c_type_for_return(return_type: str) -> str:
    clean = return_type.strip()
    aliases = {
        "BOOL": "BOOL",
        "bool": "BOOL",
        "Any": "int",
        "Player": "int",
        "Actor": "Actor",
        "Layout": "Layout",
        "Object": "int",
        "Vehicle": "int",
        "Mount": "int",
        "void": "void",
    }
    return aliases.get(clean, clean or "int")


def param_name(param: str, index: int) -> str:
    text = param.strip()
    if not text:
        return f"arg{index}"
    # Remove default markers and simple pointer/reference decorations from the name only.
    token = text.replace("*", " * ").replace("&", " & ").split()[-1]
    token = token.strip("*&")
    token = re.sub(r"[^A-Za-z0-9_]", "", token)
    if not token or token in {"const", "char", "int", "float", "bool", "BOOL", "Actor", "Layout", "Any"}:
        token = f"arg{index}"
    return token


def normalize_param_for_bridge(param: str, index: int) -> str:
    text = " ".join(param.strip().split())
    if not text:
        return f"int arg{index}"
    name = param_name(text, index)
    # Keep pointer/reference forms for known vector/string types, but collapse SDK-only
    # aliases that are not guaranteed in CodeRED_AI_Menu.cpp.
    type_part = text
    # Drop the trailing parameter name when it is present.
    if name != f"arg{index}" and type_part.endswith(name):
        type_part = type_part[: -len(name)].strip()
    aliases = {
        "Any": "int",
        "Player": "int",
        "Vehicle": "int",
        "Mount": "int",
        "Object": "int",
        "BOOL": "BOOL",
        "bool": "BOOL",
    }
    for src, dst in aliases.items():
        type_part = re.sub(rf"\b{re.escape(src)}\b", dst, type_part)
    if not type_part:
        type_part = "int"
    return f"{type_part} {name}"


def generate_cpp(entries: Sequence[BridgeEntry], profile: str) -> str:
    lines = [
        "// Code RED selected native bridge prep",
        f"// Generated: {utc_now()}",
        f"// Profile: {profile}",
        "// Include this below the existing nativeInvoke/nativePush helpers in CodeRED_AI_Menu.cpp.",
        "// This file is bridge prep, not a blind auto-install patch.",
        "",
        "namespace codered_native_bridge {",
        "",
        "struct NativeBridgeSpec {",
        "    const char* name;",
        "    unsigned long long hash;",
        "    const char* category;",
        "    const char* return_type;",
        "    int param_count;",
        "};",
        "",
        "static const NativeBridgeSpec kSelectedNatives[] = {",
    ]
    for entry in entries:
        if entry.status != "ready" or not entry.hash:
            continue
        lines.append(f'    {{"{entry.name}", {entry.hash}ULL, "{entry.category}", "{entry.return_type}", {len(entry.params)}}},')
    lines.extend(["};", ""])
    for entry in entries:
        if entry.status != "ready" or not entry.hash:
            continue
        ret = c_type_for_return(entry.return_type)
        args = []
        names = []
        for idx, raw in enumerate(entry.params):
            # Keep SDK param text because the ASI source already defines common aliases.
            name = param_name(raw, idx)
            args.append(normalize_param_for_bridge(raw, idx))
            names.append(name)
        # Ensure names from signature are usable in call. If raw SDK params have names,
        # use extracted trailing names. For params like const char* layoutName this works.
        signature = ", ".join(args)
        call_args = ", ".join(names)
        wrapper_name = safe_identifier(entry.name)
        if ret == "void":
            body = f"nativeInvoke<void>({entry.hash}ULL{', ' if call_args else ''}{call_args});"
            lines.append(f"static void {wrapper_name}({signature}) {{ {body} }}")
        else:
            body = f"return nativeInvoke<{ret}>({entry.hash}ULL{', ' if call_args else ''}{call_args});"
            lines.append(f"static {ret} {wrapper_name}({signature}) {{ {body} }}")
    lines.extend(["", "} // namespace codered_native_bridge", ""])
    return "\n".join(lines)


def write_outputs(root: Path, entries: Sequence[BridgeEntry], meta: dict, profile: str) -> dict:
    data_dir = root / "data" / "codered"
    logs_dir = root / "logs"
    data_dir.mkdir(parents=True, exist_ok=True)
    logs_dir.mkdir(parents=True, exist_ok=True)
    ready = [entry for entry in entries if entry.status == "ready"]
    partial = [entry for entry in entries if entry.status != "ready"]
    manifest = {
        "version": VERSION,
        "generated_utc": utc_now(),
        "profile": profile,
        "counts": {
            "selected": len(entries),
            "ready": len(ready),
            "partial": len(partial),
            "sdk_database_entries": meta.get("sdk_count", 0),
            "native_database_entries": meta.get("db_count", 0),
        },
        "sources": {"native_database": meta.get("db_path"), "sdk_natives": meta.get("sdk_path")},
        "entries": [asdict(entry) for entry in entries],
    }
    manifest_path = data_dir / "native_bridge_manifest.json"
    csv_path = data_dir / "native_bridge_manifest.csv"
    cpp_path = data_dir / "native_bridge_selected_wrappers.cpp"
    compile_probe_path = data_dir / "native_bridge_compile_probe.cpp"
    report_json = logs_dir / "CodeRED_Native_Bridge_Generation_Report.json"
    report_md = logs_dir / "CodeRED_Native_Bridge_Generation_Report.md"
    pass_log = logs_dir / "CodeRED_Native_Bridge_Generation_Lane_Pass_2026-05-03.md"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["name", "hash", "category", "return_type", "param_count", "sdk_line", "db_line", "status", "warnings"])
        writer.writeheader()
        for entry in entries:
            writer.writerow({
                "name": entry.name,
                "hash": entry.hash,
                "category": entry.category,
                "return_type": entry.return_type,
                "param_count": len(entry.params),
                "sdk_line": entry.sdk_line,
                "db_line": entry.db_line,
                "status": entry.status,
                "warnings": "|".join(entry.warnings),
            })
    cpp_path.write_text(generate_cpp(entries, profile), encoding="utf-8")
    compile_probe_path.write_text(
        "#include <type_traits>\n"
        "using BOOL=int; using Actor=int; using Layout=int;\n"
        "struct Vector2 { float x; float y; };\n"
        "struct Vector3 { float x; float y; float z; };\n"
        "template <typename R, typename... Args>\n"
        "R nativeInvoke(unsigned long long, Args...) { if constexpr (!std::is_same_v<R, void>) return R{}; }\n"
        "#include \"native_bridge_selected_wrappers.cpp\"\n"
        "int main(){ return codered_native_bridge::kSelectedNatives[0].hash ? 0 : 1; }\n",
        encoding="utf-8",
    )
    lines = [
        "# Code RED Native Bridge Generation Report",
        "",
        f"Generated: `{manifest['generated_utc']}`",
        f"Profile: `{profile}`",
        "",
        "## Result",
        "",
        f"- Selected natives: {len(entries)}",
        f"- Ready wrappers: {len(ready)}",
        f"- Partial entries: {len(partial)}",
        f"- SDK native entries parsed: {meta.get('sdk_count', 0)}",
        f"- Native database entries loaded: {meta.get('db_count', 0)}",
        "",
        "## Outputs",
        "",
        f"- `{manifest_path.relative_to(root)}`",
        f"- `{csv_path.relative_to(root)}`",
        f"- `{cpp_path.relative_to(root)}`",
        f"- `{compile_probe_path.relative_to(root)}`",
        "",
        "## Safety Notes",
        "",
        "- This is selected bridge prep only; it does not auto-patch the ASI.",
        "- Use generated wrappers one lane at a time with compile and in-game proof.",
        "- Partial entries are intentionally not emitted as callable wrappers.",
        "",
        "## Selected Natives",
        "",
        "| Status | Name | Hash | Category | Params | Warnings |",
        "|---|---|---:|---|---:|---|",
    ]
    for entry in entries:
        lines.append(f"| {entry.status} | {entry.name} | `{entry.hash}` | {entry.category} | {len(entry.params)} | {'; '.join(entry.warnings)} |")
    report_text = "\n".join(lines) + "\n"
    report_md.write_text(report_text, encoding="utf-8")
    report_json.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    pass_log.write_text(report_text, encoding="utf-8")
    return {
        "manifest": str(manifest_path),
        "csv": str(csv_path),
        "cpp": str(cpp_path),
        "compile_probe": str(compile_probe_path),
        "report_md": str(report_md),
        "report_json": str(report_json),
        "pass_log": str(pass_log),
        "ready": len(ready),
        "partial": len(partial),
        "selected": len(entries),
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Generate selected native bridge wrappers for Code RED.")
    parser.add_argument("--root", default=".", help="Code RED root folder")
    parser.add_argument("--profile", default=DEFAULT_PROFILE, choices=sorted(DEFAULT_PROFILES), help="Selection profile")
    parser.add_argument("--native", action="append", default=[], help="Extra native name to include")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    root = Path(args.root).resolve()
    entries, meta = build_entries(root, args.profile, args.native)
    outputs = write_outputs(root, entries, meta, args.profile)
    print(f"Native bridge generation: {'PASS' if outputs['partial'] == 0 else 'PARTIAL'}")
    print(f"Profile: {args.profile}")
    print(f"Selected: {outputs['selected']}")
    print(f"Ready wrappers: {outputs['ready']}")
    print(f"Partial entries: {outputs['partial']}")
    print(f"Report: {outputs['report_md']}")
    return 0 if outputs["ready"] > 0 else 2

if __name__ == "__main__":
    raise SystemExit(main())
