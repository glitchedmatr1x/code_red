# Code RED One-App Lane Status

Root: `/mnt/data/codered_work`
Readiness score: **94%**

## Counts

- Ready: 14
- Ready but needs proof: 2
- Missing required files: 0

## Lanes

| State | Category | Lane | Missing required | Replaces external |
|---|---|---|---|---|
| ready | Core | Code RED Workbench |  |  |
| ready | Core | Repo Doctor |  |  |
| ready | Build | Build Assistant |  |  |
| ready-no-proof | AI Trainer | AI Trainer / ScriptHookRDR Menu |  | standalone trainer menu setup |
| ready | AI Trainer | Trainer AI Controller |  |  |
| ready | Natives | Native Probe / Bridge Prep |  | manual native hash searches |
| ready | Scripts | Script Compile Lab |  | SC-CL, Magic RDR script compile helpers |
| ready | Archives | RPF Edit Lab |  | Magic RDR basic RPF browsing/patch staging |
| ready | Archives | CodeX / Model XML Bundle Helpers |  | CodeX batch bundle steps |
| ready | Models | WFT / RSC5 Edit Bridge |  | partial model viewer/export helpers |
| ready | World | WSI / Map / Gringo Tools |  | manual WSI/WGD cross-checking |
| ready-no-proof | World | Terrainboundres Tools |  | manual terrainboundres browsing |
| ready | Vehicles | Vehicle / Gringo Research |  |  |
| ready | Tuner | CodeRED Tuner / Arcade |  |  |
| ready | Companion | MP Companion |  |  |
| ready | Research | Logs / Research Browser |  |  |
