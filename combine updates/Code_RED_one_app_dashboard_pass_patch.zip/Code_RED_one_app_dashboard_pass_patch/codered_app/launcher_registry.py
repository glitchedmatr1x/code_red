from __future__ import annotations

import json
import os
import shutil
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable, Sequence

from .paths import CodeRedPaths


@dataclass(frozen=True)
class AppLane:
    id: str
    title: str
    category: str
    description: str
    command: tuple[str, ...]
    required_paths: tuple[str, ...] = ()
    optional_paths: tuple[str, ...] = ()
    proof_paths: tuple[str, ...] = ()
    replaces_external: tuple[str, ...] = ()
    notes: str = ""


@dataclass
class LaneStatus:
    id: str
    title: str
    category: str
    state: str
    ready_required: int
    total_required: int
    ready_optional: int
    total_optional: int
    command: list[str]
    missing_required: list[str] = field(default_factory=list)
    present_required: list[str] = field(default_factory=list)
    present_optional: list[str] = field(default_factory=list)
    present_proof: list[str] = field(default_factory=list)
    replaces_external: list[str] = field(default_factory=list)
    description: str = ""
    notes: str = ""


LANES: tuple[AppLane, ...] = (
    AppLane(
        id="main_workbench",
        title="Code RED Workbench",
        category="Core",
        description="Canonical one-app host path. Starts at repo root by default.",
        command=("py", "-3", "main.py"),
        required_paths=("main.py", "python_workbench.py", "Run_Code_RED.bat"),
        proof_paths=("logs/CodeRED_Main_Launcher_Unification_Pass_2026-05-03.md",),
    ),
    AppLane(
        id="repo_doctor",
        title="Repo Doctor",
        category="Core",
        description="Checks active folders, launchers, generated clutter, and obvious repo drift.",
        command=("py", "-3", "tools/codered_repo_doctor.py"),
        required_paths=("tools/codered_repo_doctor.py", "Run_CodeRED_Repo_Doctor.bat"),
    ),
    AppLane(
        id="build_assistant",
        title="Build Assistant",
        category="Build",
        description="Guided ASI/build/install assistant for Code RED ScriptHook lanes.",
        command=("py", "-3", "tools/codered_build_assistant.py", "gui"),
        required_paths=("tools/codered_build_assistant.py", "Run_CodeRED_Build_Assistant.bat"),
    ),
    AppLane(
        id="ai_trainer_menu",
        title="AI Trainer / ScriptHookRDR Menu",
        category="AI Trainer",
        description="Builds/validates the AI Menu, actor enum map, rosters, and behavior actions.",
        command=("cmd", "/c", "Run_CodeRED_AI_Menu_Setup.bat"),
        required_paths=(
            "Run_CodeRED_AI_Menu_Setup.bat",
            "tools/codered_actor_enum_tool.py",
            "data/codered/npc_roster.txt",
            "data/codered/actor_enum_map.csv",
            "data/codered/ai_behavior_actions.csv",
            "related_apps/Code_RED_ScriptHookRDR_AI_Menu/CodeRED_AI_Menu.cpp",
        ),
        proof_paths=("logs/CodeRED_AI_Menu_Behavior_Faction_Pass_2026-05-02.md",),
        replaces_external=("standalone trainer menu setup",),
    ),
    AppLane(
        id="trainer_controller",
        title="Trainer AI Controller",
        category="AI Trainer",
        description="Writes trainer-spawned companion state/action plans for follow, guard, attack, regroup, mount, and dismiss.",
        command=("py", "-3", "tools/codered_trainer_ai_controller_v1.py", "status"),
        required_paths=("tools/codered_trainer_ai_controller_v1.py", "tools/codered_npc_roster.py"),
        optional_paths=("scratch/codered_trainer_ai_state.json", "scratch/codered_trainer_ai_action_plan.json"),
    ),
    AppLane(
        id="native_probe",
        title="Native Probe / Bridge Prep",
        category="Natives",
        description="Native discovery and bridge-prep lane. This replaces blind manual native copying with selected proof gates.",
        command=("py", "-3", "tools/codered_dualgun_native_probe.py"),
        required_paths=("tools/codered_dualgun_native_probe.py", "related_apps/Code_RED_ScriptHookRDR_DualGunLab/CodeRED_DualGunLab.cpp"),
        optional_paths=("tools/codered_dualgun_plan_builder.py",),
        replaces_external=("manual native hash searches",),
    ),
    AppLane(
        id="script_compile_lab",
        title="Script Compile Lab",
        category="Scripts",
        description="SC-CL/Magic-RDR compile/recompile staging lane. Existing binary roundtrip remains proof-gated.",
        command=("cmd", "/c", "related_apps/code_red_sccl_attempt_bundle_v1/code_red_script_compile_lab_v1/README.md"),
        required_paths=("related_apps/code_red_sccl_attempt_bundle_v1/code_red_script_compile_lab_v1",),
        optional_paths=("related_apps/code_red_sccl_attempt_bundle_v1/code_red_sccl_windows_build_kit_v1",),
        replaces_external=("SC-CL", "Magic RDR script compile helpers"),
        notes="Keep compile/recompile sample-based until full WSC binary roundtrip is proven.",
    ),
    AppLane(
        id="rpf_edit_lab",
        title="RPF Edit Lab",
        category="Archives",
        description="Archive inventory, export, copied-archive patching, and proof utilities.",
        command=("py", "-3", "related_apps/rpf_edit_lab.py"),
        required_paths=("related_apps/rpf_edit_lab.py", "tools/codered_rpf_utils.py", "tools/codered_rpf_utils_patch.py"),
        replaces_external=("Magic RDR basic RPF browsing/patch staging",),
    ),
    AppLane(
        id="codex_bundle",
        title="CodeX / Model XML Bundle Helpers",
        category="Archives",
        description="Import/export helpers for CodeX-style XML/model bundles.",
        command=("py", "-3", "tools/codered_codex_bundle_cli.py"),
        required_paths=("tools/codered_codex_bundle_cli.py", "tools/codered_modelxml_bundle_cli.py"),
        optional_paths=("Export_CodeX_Bundle_CLI.bat", "Import_CodeX_Bundle_CLI.bat"),
        replaces_external=("CodeX batch bundle steps",),
    ),
    AppLane(
        id="wft_edit_bridge",
        title="WFT / RSC5 Edit Bridge",
        category="Models",
        description="WFT/RSC5 inspection, unpack, preview, and model bridge research lane.",
        command=("py", "-3", "tools/codered_wft_rsc5_tool.py"),
        required_paths=("tools/codered_wft_rsc5_tool.py", "related_apps/Code_RED_WFT_RSC5_EditBridge_Pass9_MENU_FIX"),
        optional_paths=("tools/codered_wft_wedt_attachment_decoder.py", "tools/codered_obj_viewer.py"),
        replaces_external=("partial model viewer/export helpers",),
    ),
    AppLane(
        id="wsi_tools",
        title="WSI / Map / Gringo Tools",
        category="World",
        description="WSI explorer, sector/array export, WGD export, gringo correlator, and map-layer resolver.",
        command=("py", "-3", "tools/codered_wsi_gringo_correlator.py"),
        required_paths=(
            "tools/codered_wsi_explorer.py",
            "tools/codered_wsi_sector_export.py",
            "tools/codered_wsi_array_export.py",
            "tools/codered_gringo_wgd_export.py",
            "tools/codered_wsi_gringo_correlator.py",
            "tools/codered_map_layer_correlator.py",
        ),
        proof_paths=("research/blackwater_wsi_gringo_correlation_outputs/wsi_gringo_correlation_master.json",),
        replaces_external=("manual WSI/WGD cross-checking",),
    ),
    AppLane(
        id="terrain_tools",
        title="Terrainboundres Tools",
        category="World",
        description="Terrain-bound inventory/export/patch-proof lane for WTB tiles.",
        command=("py", "-3", "tools/codered_terrainboundres_tool.py"),
        required_paths=("tools/codered_terrainboundres_tool.py",),
        proof_paths=("logs/CodeRED_Terrainboundres_Tooling_Changelog_2026-04-30.md",),
        replaces_external=("manual terrainboundres browsing",),
    ),
    AppLane(
        id="vehicle_research",
        title="Vehicle / Gringo Research",
        category="Vehicles",
        description="Car/truck inventory, vehicle generator trace, gringo scripts, locsets, and templates.",
        command=("py", "-3", "tools/codered_car_truck_inventory.py"),
        required_paths=("tools/codered_car_truck_inventory.py", "research/CodeRED_RESEARCH_SYNTHESIS_2026-04-29.md"),
        proof_paths=("research/car_truck_inventory/car_truck_inventory.md",),
    ),
    AppLane(
        id="tuner_arcade",
        title="CodeRED Tuner / Arcade",
        category="Tuner",
        description="Vehicle tune UI, presets, arcade smoke test, screenshots, and runtime settings.",
        command=("cmd", "/c", "related_apps/CodeRED_Tuner/run_CodeRED_Tuner.bat"),
        required_paths=("related_apps/CodeRED_Tuner/codered_tuner.py", "related_apps/CodeRED_Tuner/code_red_arcade.py", "related_apps/CodeRED_Tuner/run_CodeRED_Tuner.bat"),
        optional_paths=("related_apps/CodeRED_Tuner/run_CodeRed_Arcade.bat", "related_apps/CodeRED_Tuner/stock_vehicle_files"),
    ),
    AppLane(
        id="mp_companion",
        title="MP Companion",
        category="Companion",
        description="Companion lane kept as an internal app section, not a competing startup workspace.",
        command=("py", "-3", "related_apps/run_mp_companion.py"),
        required_paths=("related_apps/run_mp_companion.py", "related_apps/Code_RED_MP_Companion_v19/mp_companion.py"),
    ),
    AppLane(
        id="logs_research",
        title="Logs / Research Browser",
        category="Research",
        description="Curated project log index and research manifest browser source.",
        command=("py", "-3", "tools/codered_readable_root_indexer.py", "--help"),
        required_paths=("logs", "research/CodeRED_RESEARCH_MANIFEST.csv"),
        optional_paths=("logs/CodeRED_LOG_INDEX.md", "research/CodeRED_RESEARCH_SYNTHESIS_2026-04-29.md"),
    ),
)


def _path_exists(root: Path, item: str) -> bool:
    path = root / item
    return path.exists()


def _resolve_command(root: Path, command: Sequence[str]) -> list[str]:
    resolved: list[str] = []
    for index, part in enumerate(command):
        if index == 0:
            resolved.append(part)
            continue
        if part.endswith((".py", ".bat", ".cmd", ".exe", ".md", ".txt")) or "/" in part or "\\" in part:
            maybe = root / part
            resolved.append(str(maybe) if maybe.exists() else part)
        else:
            resolved.append(part)
    return resolved


def lane_status(paths: CodeRedPaths, lane: AppLane) -> LaneStatus:
    root = paths.root
    present_required = [item for item in lane.required_paths if _path_exists(root, item)]
    missing_required = [item for item in lane.required_paths if not _path_exists(root, item)]
    present_optional = [item for item in lane.optional_paths if _path_exists(root, item)]
    present_proof = [item for item in lane.proof_paths if _path_exists(root, item)]

    if missing_required:
        state = "missing"
    elif lane.proof_paths and not present_proof:
        state = "ready-no-proof"
    else:
        state = "ready"

    return LaneStatus(
        id=lane.id,
        title=lane.title,
        category=lane.category,
        state=state,
        ready_required=len(present_required),
        total_required=len(lane.required_paths),
        ready_optional=len(present_optional),
        total_optional=len(lane.optional_paths),
        command=_resolve_command(root, lane.command),
        missing_required=missing_required,
        present_required=present_required,
        present_optional=present_optional,
        present_proof=present_proof,
        replaces_external=list(lane.replaces_external),
        description=lane.description,
        notes=lane.notes,
    )


def discover_lanes(root: Path | None = None) -> list[LaneStatus]:
    paths = CodeRedPaths.detect(root)
    return [lane_status(paths, lane) for lane in LANES]


def build_status_report(root: Path | None = None) -> dict:
    paths = CodeRedPaths.detect(root)
    statuses = discover_lanes(paths.root)
    counts: dict[str, int] = {"ready": 0, "ready-no-proof": 0, "missing": 0}
    categories: dict[str, dict[str, int]] = {}
    for status in statuses:
        counts[status.state] = counts.get(status.state, 0) + 1
        bucket = categories.setdefault(status.category, {"ready": 0, "ready-no-proof": 0, "missing": 0, "total": 0})
        bucket[status.state] = bucket.get(status.state, 0) + 1
        bucket["total"] += 1
    # Ready lanes count fully. Proof-gated lanes count halfway so the score does not
    # claim 100% until proof logs exist for every lane that requires them.
    total = len(statuses)
    weighted_ready = counts.get("ready", 0) + (counts.get("ready-no-proof", 0) * 0.5)
    score = int(round((weighted_ready / total) * 100)) if total else 0
    return {
        "root": str(paths.root),
        "score": score,
        "counts": counts,
        "categories": categories,
        "lanes": [asdict(status) for status in statuses],
    }


def report_to_markdown(report: dict) -> str:
    lines = [
        "# Code RED One-App Lane Status",
        "",
        f"Root: `{report['root']}`",
        f"Readiness score: **{report['score']}%**",
        "",
        "## Counts",
        "",
        f"- Ready: {report['counts'].get('ready', 0)}",
        f"- Ready but needs proof: {report['counts'].get('ready-no-proof', 0)}",
        f"- Missing required files: {report['counts'].get('missing', 0)}",
        "",
        "## Lanes",
        "",
        "| State | Category | Lane | Missing required | Replaces external |",
        "|---|---|---|---|---|",
    ]
    for lane in report["lanes"]:
        missing = ", ".join(lane["missing_required"]) if lane["missing_required"] else ""
        replaces = ", ".join(lane["replaces_external"]) if lane["replaces_external"] else ""
        lines.append(f"| {lane['state']} | {lane['category']} | {lane['title']} | {missing} | {replaces} |")
    return "\n".join(lines) + "\n"


def write_status_outputs(root: Path | None = None, out_dir: Path | None = None) -> dict:
    paths = CodeRedPaths.detect(root)
    report = build_status_report(paths.root)
    target = out_dir or (paths.logs / "one_app_status")
    target.mkdir(parents=True, exist_ok=True)
    json_path = target / "one_app_lane_status.json"
    md_path = target / "one_app_lane_status.md"
    json_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    md_path.write_text(report_to_markdown(report), encoding="utf-8")
    return {"json": str(json_path), "markdown": str(md_path), "report": report}
