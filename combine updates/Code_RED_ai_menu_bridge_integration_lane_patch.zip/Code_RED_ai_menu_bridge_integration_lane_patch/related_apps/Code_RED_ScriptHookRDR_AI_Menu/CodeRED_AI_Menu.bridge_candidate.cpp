// CodeRED_AI_Menu.cpp
// Conservative ScriptHookRDR in-game menu scaffold.
//
// Codex/build-ready note:
// This source resolves ScriptHookRDR exports dynamically with GetProcAddress instead
// of linking against a ScriptHookRDR import .lib. That keeps the first-pass build
// simple: cl.exe can produce a .asi DLL using only Windows SDK + the repo source.
//
// This pass draws an overlay, loads an editable NPC roster, writes action-plan JSON,
// and can spawn/follow/dismiss actors through ScriptHookRDR native exports.

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <algorithm>
#include <cerrno>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <sstream>
#include <string>
#include <type_traits>
#include <unordered_map>
#include <vector>

namespace codered {

using KeyboardHandler = void(*)(DWORD, WORD, BYTE, BOOL, BOOL, BOOL, BOOL);
using ScriptRegisterFn = void(*)(HMODULE, void(*)());
using ScriptUnregisterFn = void(*)(HMODULE);
using KeyboardHandlerRegisterFn = void(*)(KeyboardHandler);
using KeyboardHandlerUnregisterFn = void(*)(KeyboardHandler);
using ScriptWaitFn = void(*)(DWORD);
using DrawRectFn = void(*)(float, float, float, float, int, int, int, int, float);
using DrawTextFn = void(*)(float, float, const char*, int, int, int, int, int, float, int);
using NativeInitFn = void(*)(unsigned long long);
using NativePush64Fn = void(*)(unsigned long long);
using NativeCallFn = unsigned long long*(*)();
using WorldGetAllActorsFn = int(*)(int*, int);

// ScriptHookRDR font/justification ids from sdk/inc/enums.h.
constexpr int FONT_REDEMPTION = 2;
constexpr int JUSTIFY_LEFT = 0;
constexpr float PI = 3.14159265358979323846f;
constexpr int FACTION_PLAYER = 2;
constexpr int FACTION_US_LAW = 8;
constexpr int FACTION_MEXICAN_BANDITO = 12;
constexpr int FACTION_GENERIC_CRIMINAL = 13;
constexpr int FACTION_CATTLE_RUSTLER = 14;
constexpr int FACTION_INDIAN_RAIDER = 15;
constexpr int FACTION_MEXICAN_SOLDIER = 16;

using Actor = int;
using Layout = int;

struct Vector2 {
    float x;
    float y;
};

struct Vector3 {
    float x;
    float y;
    float z;
};

static HMODULE g_scriptHook = nullptr;
static ScriptRegisterFn g_scriptRegister = nullptr;
static ScriptUnregisterFn g_scriptUnregister = nullptr;
static KeyboardHandlerRegisterFn g_keyboardHandlerRegister = nullptr;
static KeyboardHandlerUnregisterFn g_keyboardHandlerUnregister = nullptr;
static ScriptWaitFn g_scriptWait = nullptr;
static DrawRectFn g_drawRect = nullptr;
static DrawTextFn g_drawText = nullptr;
static NativeInitFn g_nativeInit = nullptr;
static NativePush64Fn g_nativePush64 = nullptr;
static NativeCallFn g_nativeCall = nullptr;
static WorldGetAllActorsFn g_worldGetAllActors = nullptr;
static HMODULE g_module = nullptr;
static volatile LONG g_stopRequested = 0;
static volatile LONG g_registered = 0;
static volatile LONG g_nativeReady = 0;

static bool g_menuOpen = false;
static int g_menuIndex = 0;
static int g_npcIndex = 0;
static bool g_dirtyRoster = true;
static bool g_dirtyActorMap = true;
static bool g_dirtyActions = true;
static bool g_configLoaded = false;
static DWORD g_lastKeyMs = 0;
static Layout g_layout = 0;
static int g_spawnCounter = 0;
static bool g_actorEnumCacheValid = false;
static std::string g_actorEnumCacheRaw;
static int g_actorEnumCacheValue = 0;
static bool g_savedPlayerFaction = false;
static int g_originalPlayerFaction = FACTION_PLAYER;
static int g_playerSideFaction = FACTION_PLAYER;

static std::string g_rosterPath = "data/codered/npc_roster.txt";
static std::string g_actorEnumMapPath = "data/codered/actor_enum_map.csv";
static std::string g_actionsPath = "data/codered/ai_behavior_actions.csv";
static std::string g_actionPlanPath = "scratch/codered_ai_action_plan.json";
static std::string g_status = "CodeRED AI Menu ready";

static std::vector<std::string> g_roster;
static std::unordered_map<std::string, int> g_actorEnumMap;
static std::unordered_map<std::string, std::string> g_actionLabels;
static size_t g_actorEnumRowsLoaded = 0;
static std::vector<Actor> g_spawnedActors;
static std::vector<std::string> g_actions = {
    "spawn_selected_npc_request",
    "follow_player_request",
    "guard_position_request",
    "defend_player_request",
    "attack_nearest_hostile_request",
    "idle_spawned_request",
    "wander_spawned_request",
    "regroup_near_player_request",
    "make_spawned_lawmen_request",
    "side_lawman_immunity_request",
    "side_gang_immunity_request",
    "restore_player_faction_request",
    "dismiss_ai_guest_request",
    "status_request"
};

static std::string logPath() {
    char exePath[MAX_PATH] = {};
    DWORD len = GetModuleFileNameA(nullptr, exePath, MAX_PATH);
    if (len == 0 || len >= MAX_PATH) {
        return "CodeRED_AI_Menu.log";
    }

    std::string path(exePath);
    size_t slash = path.find_last_of("\\/");
    if (slash == std::string::npos) {
        return "CodeRED_AI_Menu.log";
    }
    return path.substr(0, slash + 1) + "CodeRED_AI_Menu.log";
}

static void writeLog(const char* format, ...) {
    char message[1024] = {};
    va_list args;
    va_start(args, format);
    vsnprintf_s(message, sizeof(message), _TRUNCATE, format, args);
    va_end(args);

    SYSTEMTIME now = {};
    GetLocalTime(&now);

    char line[1280] = {};
    snprintf(line, sizeof(line),
             "[%04u-%02u-%02u %02u:%02u:%02u] %s\r\n",
             now.wYear, now.wMonth, now.wDay, now.wHour, now.wMinute,
             now.wSecond, message);

    std::string path = logPath();
    HANDLE file = CreateFileA(path.c_str(), FILE_APPEND_DATA,
                              FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr,
                              OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE) {
        return;
    }

    DWORD written = 0;
    WriteFile(file, line, static_cast<DWORD>(strlen(line)), &written, nullptr);
    CloseHandle(file);
}

static FARPROC resolveExport(const char* name, const char* decoratedName = nullptr) {
    if (!g_scriptHook) return nullptr;
    FARPROC proc = GetProcAddress(g_scriptHook, name);
    if (!proc && decoratedName) {
        proc = GetProcAddress(g_scriptHook, decoratedName);
    }
    return proc;
}

static void logMissingExport(const char* name, FARPROC proc) {
    if (!proc) {
        writeLog("Missing ScriptHookRDR export: %s", name);
    }
}

static bool resolveScriptHook(bool logMissingExports) {
    if (!g_scriptHook) {
        g_scriptHook = GetModuleHandleA("ScriptHookRDR.dll");
        if (!g_scriptHook) {
            g_scriptHook = LoadLibraryA("ScriptHookRDR.dll");
        }
    }
    if (!g_scriptHook) return false;

    FARPROC scriptRegisterProc =
        resolveExport("scriptRegister", "?scriptRegister@@YAXPEAUHINSTANCE__@@P6AXXZ@Z");
    FARPROC scriptUnregisterProc =
        resolveExport("scriptUnregister", "?scriptUnregister@@YAXPEAUHINSTANCE__@@@Z");
    FARPROC keyboardRegisterProc = resolveExport(
        "keyboardHandlerRegister", "?keyboardHandlerRegister@@YAXP6AXKGEHHHH@Z@Z");
    FARPROC keyboardUnregisterProc = resolveExport(
        "keyboardHandlerUnregister", "?keyboardHandlerUnregister@@YAXP6AXKGEHHHH@Z@Z");
    FARPROC scriptWaitProc = resolveExport("scriptWait", "?scriptWait@@YAXK@Z");
    FARPROC drawRectProc = resolveExport("drawRect", "?drawRect@@YAXMMMMHHHHM@Z");
    FARPROC drawTextProc =
        resolveExport("drawText", "?drawText@@YAXMMPEBDHHHHHMH@Z");
    FARPROC worldGetAllActorsProc =
        resolveExport("worldGetAllActors", "?worldGetAllActors@@YAHPEAHH@Z");

    if (logMissingExports) {
        logMissingExport("scriptRegister", scriptRegisterProc);
        logMissingExport("scriptUnregister", scriptUnregisterProc);
        logMissingExport("keyboardHandlerRegister", keyboardRegisterProc);
        logMissingExport("keyboardHandlerUnregister", keyboardUnregisterProc);
        logMissingExport("scriptWait", scriptWaitProc);
        logMissingExport("drawRect", drawRectProc);
        logMissingExport("drawText", drawTextProc);
    }

    g_scriptRegister = reinterpret_cast<ScriptRegisterFn>(scriptRegisterProc);
    g_scriptUnregister = reinterpret_cast<ScriptUnregisterFn>(scriptUnregisterProc);
    g_keyboardHandlerRegister = reinterpret_cast<KeyboardHandlerRegisterFn>(keyboardRegisterProc);
    g_keyboardHandlerUnregister = reinterpret_cast<KeyboardHandlerUnregisterFn>(keyboardUnregisterProc);
    g_scriptWait = reinterpret_cast<ScriptWaitFn>(scriptWaitProc);
    g_drawRect = reinterpret_cast<DrawRectFn>(drawRectProc);
    g_drawText = reinterpret_cast<DrawTextFn>(drawTextProc);
    g_worldGetAllActors = reinterpret_cast<WorldGetAllActorsFn>(worldGetAllActorsProc);

    return g_scriptRegister && g_scriptUnregister &&
           g_keyboardHandlerRegister && g_keyboardHandlerUnregister &&
           g_scriptWait && g_drawRect && g_drawText;
}

template <typename T>
static void nativePush(T value) {
    static_assert(sizeof(T) <= sizeof(unsigned long long),
                  "native argument must fit in 64 bits");
    unsigned long long value64 = 0;
    std::memcpy(&value64, &value, sizeof(T));
    g_nativePush64(value64);
}

template <typename R, typename... Args>
static R nativeInvoke(unsigned long long hash, Args... args) {
    g_nativeInit(hash);
    (nativePush(args), ...);
    unsigned long long* result = g_nativeCall();
    if constexpr (std::is_same_v<R, void>) {
        (void)result;
        return;
    } else {
        return *reinterpret_cast<R*>(result);
    }
}

// BEGIN CODERED_NATIVE_BRIDGE_SELECTED_WRAPPERS
// Generated candidate block. Do not hand-edit this section in-place.
// Re-run tools/codered_ai_menu_bridge_integration.py after regenerating native wrappers.
// Code RED selected native bridge prep
// Generated: 2026-05-03T09:08:32Z
// Profile: ai_trainer_core
// Include this below the existing nativeInvoke/nativePush helpers in CodeRED_AI_Menu.cpp.
// This file is bridge prep, not a blind auto-install patch.

namespace codered_native_bridge {

struct NativeBridgeSpec {
    const char* name;
    unsigned long long hash;
    const char* category;
    const char* return_type;
    int param_count;
};

static const NativeBridgeSpec kSelectedNatives[] = {
    {"GET_PLAYER_ACTOR", 0xE8CFDD53ULL, "actor", "Actor", 1},
    {"IS_ACTOR_VALID", 0xBA6C3E92ULL, "actor", "BOOL", 1},
    {"IS_ACTOR_ALIVE", 0x2F232639ULL, "actor", "BOOL", 1},
    {"FIND_NAMED_LAYOUT", 0x5699DE7EULL, "world", "Layout", 1},
    {"CREATE_LAYOUT", 0x6CA53214ULL, "world", "Layout", 1},
    {"CREATE_ACTOR_IN_LAYOUT", 0x8D67F397ULL, "actor", "Actor", 7},
    {"GET_POSITION", 0x99BD9D6FULL, "world", "void", 2},
    {"TELEPORT_ACTOR", 0x2D54B916ULL, "actor", "void", 5},
    {"SET_ACTOR_HEADING", 0xECE8520BULL, "actor", "void", 3},
    {"TASK_CLEAR", 0x16876A25ULL, "ai_task", "void", 1},
    {"TASK_STAND_STILL", 0x6F80965DULL, "ai_task", "void", 4},
    {"TASK_WANDER", 0x17BCA08EULL, "ai_task", "void", 2},
    {"TASK_FOLLOW_ACTOR", 0x12F0911AULL, "actor", "void", 2},
    {"TASK_KILL_CHAR", 0x1AE4B75BULL, "actor", "void", 2},
    {"AI_IS_HOSTILE_OR_ENEMY", 0x9AB964F4ULL, "ai_task", "int", 2},
    {"SET_ACTOR_FACTION", 0xCC63951AULL, "actor", "void", 2},
    {"GET_ACTOR_FACTION", 0x52E2A611ULL, "actor", "int", 1},
    {"GIVE_WEAPON_TO_ACTOR", 0x6AA0EAF2ULL, "actor", "void", 5},
    {"TASK_MOUNT", 0xB6131204ULL, "actor", "void", 6},
    {"TASK_DISMOUNT", 0x5DEF5C4AULL, "actor", "void", 2},
    {"GET_MOUNT", 0xDD31EC4EULL, "actor", "Mount", 1},
    {"GET_VEHICLE", 0xA0936EB6ULL, "vehicle", "Vehicle", 1},
    {"START_VEHICLE", 0xE4442AB2ULL, "vehicle", "void", 1},
    {"STOP_VEHICLE", 0xC2232D29ULL, "vehicle", "void", 1},
    {"TASK_VEHICLE_LEAVE", 0x6C1218A4ULL, "ai_task", "void", 1},
    {"RELEASE_LAYOUT_REF", 0xD9AC8830ULL, "world", "void", 1},
};

static Actor CR_NATIVE_GET_PLAYER_ACTOR(int player) { return nativeInvoke<Actor>(0xE8CFDD53ULL, player); }
static BOOL CR_NATIVE_IS_ACTOR_VALID(Actor actor) { return nativeInvoke<BOOL>(0xBA6C3E92ULL, actor); }
static BOOL CR_NATIVE_IS_ACTOR_ALIVE(Actor actor) { return nativeInvoke<BOOL>(0x2F232639ULL, actor); }
static Layout CR_NATIVE_FIND_NAMED_LAYOUT(const char* layoutName) { return nativeInvoke<Layout>(0x5699DE7EULL, layoutName); }
static Layout CR_NATIVE_CREATE_LAYOUT(const char* layoutName) { return nativeInvoke<Layout>(0x6CA53214ULL, layoutName); }
static Actor CR_NATIVE_CREATE_ACTOR_IN_LAYOUT(Layout layout, const char* layoutName, int actorEnum, Vector2 positionXY, float positionZ, Vector2 orientationXY, float orientationZ) { return nativeInvoke<Actor>(0x8D67F397ULL, layout, layoutName, actorEnum, positionXY, positionZ, orientationXY, orientationZ); }
static void CR_NATIVE_GET_POSITION(Actor actor, Vector3* position) { nativeInvoke<void>(0x99BD9D6FULL, actor, position); }
static void CR_NATIVE_TELEPORT_ACTOR(Actor actor, Vector3* coords, BOOL xAxis, BOOL yAxis, BOOL zAxis) { nativeInvoke<void>(0x2D54B916ULL, actor, coords, xAxis, yAxis, zAxis); }
static void CR_NATIVE_SET_ACTOR_HEADING(Actor actor, float heading, BOOL p2) { nativeInvoke<void>(0xECE8520BULL, actor, heading, p2); }
static void CR_NATIVE_TASK_CLEAR(Actor actor) { nativeInvoke<void>(0x16876A25ULL, actor); }
static void CR_NATIVE_TASK_STAND_STILL(Actor actor, float p1, int p2, int p3) { nativeInvoke<void>(0x6F80965DULL, actor, p1, p2, p3); }
static void CR_NATIVE_TASK_WANDER(int p0, int p1) { nativeInvoke<void>(0x17BCA08EULL, p0, p1); }
static void CR_NATIVE_TASK_FOLLOW_ACTOR(Actor actor, Actor followActor) { nativeInvoke<void>(0x12F0911AULL, actor, followActor); }
static void CR_NATIVE_TASK_KILL_CHAR(int p0, int p1) { nativeInvoke<void>(0x1AE4B75BULL, p0, p1); }
static int CR_NATIVE_AI_IS_HOSTILE_OR_ENEMY(int p0, int p1) { return nativeInvoke<int>(0x9AB964F4ULL, p0, p1); }
static void CR_NATIVE_SET_ACTOR_FACTION(Actor actor, int faction) { nativeInvoke<void>(0xCC63951AULL, actor, faction); }
static int CR_NATIVE_GET_ACTOR_FACTION(Actor actor) { return nativeInvoke<int>(0x52E2A611ULL, actor); }
static void CR_NATIVE_GIVE_WEAPON_TO_ACTOR(Actor actor, int weaponEnum, float ammoCount, BOOL p3, int p4) { nativeInvoke<void>(0x6AA0EAF2ULL, actor, weaponEnum, ammoCount, p3, p4); }
static void CR_NATIVE_TASK_MOUNT(int p0, int p1, int p2, int p3, int p4, int p5) { nativeInvoke<void>(0xB6131204ULL, p0, p1, p2, p3, p4, p5); }
static void CR_NATIVE_TASK_DISMOUNT(int p0, int p1) { nativeInvoke<void>(0x5DEF5C4AULL, p0, p1); }
static int CR_NATIVE_GET_MOUNT(Actor actor) { return nativeInvoke<int>(0xDD31EC4EULL, actor); }
static int CR_NATIVE_GET_VEHICLE(Actor actor) { return nativeInvoke<int>(0xA0936EB6ULL, actor); }
static void CR_NATIVE_START_VEHICLE(int vehicle) { nativeInvoke<void>(0xE4442AB2ULL, vehicle); }
static void CR_NATIVE_STOP_VEHICLE(int vehicle) { nativeInvoke<void>(0xC2232D29ULL, vehicle); }
static void CR_NATIVE_TASK_VEHICLE_LEAVE(int p0) { nativeInvoke<void>(0x6C1218A4ULL, p0); }
static void CR_NATIVE_RELEASE_LAYOUT_REF(Layout layout) { nativeInvoke<void>(0xD9AC8830ULL, layout); }

} // namespace codered_native_bridge
// END CODERED_NATIVE_BRIDGE_SELECTED_WRAPPERS

static bool nativeReady() {
    return InterlockedCompareExchange(&g_nativeReady, 0, 0) != 0 &&
           g_nativeInit && g_nativePush64 && g_nativeCall;
}

static bool resolveNativeBridge(bool logMissingExports) {
    if (!g_scriptHook) return false;

    FARPROC nativeInitProc = resolveExport("nativeInit", "?nativeInit@@YAX_K@Z");
    FARPROC nativePush64Proc = resolveExport("nativePush64", "?nativePush64@@YAX_K@Z");
    FARPROC nativeCallProc = resolveExport("nativeCall", "?nativeCall@@YAPEA_KXZ");

    if (logMissingExports) {
        logMissingExport("nativeInit", nativeInitProc);
        logMissingExport("nativePush64", nativePush64Proc);
        logMissingExport("nativeCall", nativeCallProc);
    }

    g_nativeInit = reinterpret_cast<NativeInitFn>(nativeInitProc);
    g_nativePush64 = reinterpret_cast<NativePush64Fn>(nativePush64Proc);
    g_nativeCall = reinterpret_cast<NativeCallFn>(nativeCallProc);

    const bool ready = g_nativeInit && g_nativePush64 && g_nativeCall;
    InterlockedExchange(&g_nativeReady, ready ? 1 : 0);
    return ready;
}

static void waitFrame(DWORD ms) {
    if (g_scriptWait) {
        g_scriptWait(ms);
    } else {
        Sleep(ms);
    }
}

static void drawRectSafe(float x, float y, float width, float height, int r, int g, int b, int a, float rounding) {
    if (g_drawRect) g_drawRect(x, y, width, height, r, g, b, a, rounding);
}

static void drawTextSafe(float x, float y, const char* text, int r, int g, int b, int a, int fontId, float fontSize, int justification) {
    if (g_drawText) g_drawText(x, y, text, r, g, b, a, fontId, fontSize, justification);
}

static std::string trim(const std::string& value) {
    size_t first = value.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return "";
    size_t last = value.find_last_not_of(" \t\r\n");
    return value.substr(first, last - first + 1);
}

static std::string lowerCopy(const std::string& value) {
    std::string out = value;
    std::transform(out.begin(), out.end(), out.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return out;
}

static std::string stripInlineComment(const std::string& value) {
    bool inQuotes = false;
    for (size_t i = 0; i < value.size(); ++i) {
        const char c = value[i];
        if (c == '"') {
            inQuotes = !inQuotes;
            continue;
        }
        if (!inQuotes && (c == '#' || c == ';')) {
            return value.substr(0, i);
        }
    }
    return value;
}

static std::vector<std::string> splitCsvLine(const std::string& line) {
    std::vector<std::string> fields;
    std::string current;
    bool inQuotes = false;

    for (size_t i = 0; i < line.size(); ++i) {
        const char c = line[i];
        if (c == '"') {
            if (inQuotes && i + 1 < line.size() && line[i + 1] == '"') {
                current.push_back('"');
                ++i;
            } else {
                inQuotes = !inQuotes;
            }
            continue;
        }
        if (!inQuotes && c == ',') {
            fields.push_back(trim(current));
            current.clear();
            continue;
        }
        current.push_back(c);
    }

    fields.push_back(trim(current));
    return fields;
}

static std::vector<std::string> splitAliases(const std::string& text) {
    std::vector<std::string> aliases;
    std::string current;
    for (char c : text) {
        if (c == '|' || c == ';') {
            std::string clean = trim(current);
            if (!clean.empty()) aliases.push_back(clean);
            current.clear();
        } else {
            current.push_back(c);
        }
    }
    std::string clean = trim(current);
    if (!clean.empty()) aliases.push_back(clean);
    return aliases;
}

static bool parseActorEnumToken(const std::string& raw, int& outValue) {
    std::string text = trim(raw);
    if (text.empty() || text == "?" || text == "null" || text == "NULL" ||
        text == "todo" || text == "TODO") {
        return false;
    }

    int base = 10;
    if (text.size() > 2 && text[0] == '0' &&
        (text[1] == 'x' || text[1] == 'X')) {
        base = 16;
    }

    errno = 0;
    char* end = nullptr;
    long long value = std::strtoll(text.c_str(), &end, base);
    if (errno != 0 || end == text.c_str() || !trim(end).empty()) {
        return false;
    }
    if (value <= 0 || value > INT_MAX) {
        return false;
    }

    outValue = static_cast<int>(value);
    return true;
}

static std::string jsonEscape(const std::string& value) {
    std::ostringstream out;
    for (char c : value) {
        switch (c) {
            case '\\': out << "\\\\"; break;
            case '"': out << "\\\""; break;
            case '\n': out << "\\n"; break;
            case '\r': out << "\\r"; break;
            case '\t': out << "\\t"; break;
            default: out << c; break;
        }
    }
    return out.str();
}

static std::string enumHex(int actorEnum) {
    char buffer[32] = {};
    snprintf(buffer, sizeof(buffer), "0x%08X",
             static_cast<unsigned int>(actorEnum));
    return std::string(buffer);
}

static std::string displayRosterName(const std::string& raw) {
    std::string text = trim(stripInlineComment(raw));
    size_t best = std::string::npos;
    for (char marker : {'|', '=', ','}) {
        size_t pos = text.find(marker);
        if (pos != std::string::npos &&
            (best == std::string::npos || pos < best)) {
            best = pos;
        }
    }
    if (best != std::string::npos) {
        text = text.substr(0, best);
    }
    return trim(text);
}

static bool resolveInlineActorEnum(const std::string& raw, int& actorEnum) {
    std::string text = trim(stripInlineComment(raw));
    for (char marker : {'|', '=', ','}) {
        size_t pos = text.find(marker);
        if (pos != std::string::npos) {
            std::string rhs = trim(text.substr(pos + 1));
            if (parseActorEnumToken(rhs, actorEnum)) return true;
        }
    }
    return parseActorEnumToken(text, actorEnum);
}

static void loadConfig() {
    if (g_configLoaded) return;
    g_configLoaded = true;

    std::ifstream file("CodeRED_AI_Menu.ini");
    if (!file) return;

    std::string section;
    std::string line;
    while (std::getline(file, line)) {
        std::string clean = trim(stripInlineComment(line));
        if (clean.empty()) continue;
        if (clean.front() == '[' && clean.back() == ']') {
            section = lowerCopy(trim(clean.substr(1, clean.size() - 2)));
            continue;
        }
        if (section != "paths") continue;

        size_t eq = clean.find('=');
        if (eq == std::string::npos) continue;
        std::string key = lowerCopy(trim(clean.substr(0, eq)));
        std::string value = trim(clean.substr(eq + 1));
        if (value.empty()) continue;

        if (key == "roster") {
            g_rosterPath = value;
        } else if (key == "actor_enum_map" || key == "actor_map" ||
                   key == "enum_map") {
            g_actorEnumMapPath = value;
        } else if (key == "behavior_actions" || key == "actions" ||
                   key == "action_menu") {
            g_actionsPath = value;
        } else if (key == "action_plan") {
            g_actionPlanPath = value;
        }
    }

    writeLog("Config loaded: roster=%s actor_enum_map=%s actions=%s action_plan=%s",
             g_rosterPath.c_str(), g_actorEnumMapPath.c_str(),
             g_actionsPath.c_str(), g_actionPlanPath.c_str());
}

static void loadActorEnumMap() {
    loadConfig();
    g_actorEnumMap.clear();
    g_actorEnumRowsLoaded = 0;
    g_actorEnumCacheValid = false;

    std::ifstream file(g_actorEnumMapPath.c_str());
    if (!file) {
        g_dirtyActorMap = false;
        writeLog("Actor enum map not found: %s", g_actorEnumMapPath.c_str());
        return;
    }

    std::string line;
    while (std::getline(file, line)) {
        std::string clean = trim(stripInlineComment(line));
        if (clean.empty()) continue;

        const size_t firstComma = clean.find(',');
        if (firstComma != std::string::npos) {
            std::vector<std::string> fields = splitCsvLine(clean);
            if (fields.empty()) continue;
            if (fields.size() >= 2) {
                const std::string key0 = lowerCopy(fields[0]);
                const std::string key1 = lowerCopy(fields[1]);
                if ((key0 == "label" || key0 == "name" || key0 == "actor") &&
                    (key1 == "actor_enum" || key1 == "enum" ||
                     key1 == "value" || key1 == "actorenum")) {
                    continue;
                }
            }

            std::string label = trim(fields[0]);
            std::string enumText = fields.size() >= 2 ? fields[1] : "";
            int enumValue = 0;
            if (label.empty() || !parseActorEnumToken(enumText, enumValue)) {
                continue;
            }

            g_actorEnumMap[lowerCopy(label)] = enumValue;
            ++g_actorEnumRowsLoaded;

            if (fields.size() >= 5) {
                for (const std::string& alias : splitAliases(fields[4])) {
                    g_actorEnumMap[lowerCopy(alias)] = enumValue;
                }
            }
            continue;
        }

        const size_t inlineEq = clean.find('=');
        const size_t inlinePipe = clean.find('|');
        if (inlineEq != std::string::npos || inlinePipe != std::string::npos) {
            size_t pos = inlineEq;
            if (inlinePipe != std::string::npos &&
                (pos == std::string::npos || inlinePipe < pos)) {
                pos = inlinePipe;
            }
            std::string label = trim(clean.substr(0, pos));
            std::string enumText = trim(clean.substr(pos + 1));
            int enumValue = 0;
            if (!label.empty() && parseActorEnumToken(enumText, enumValue)) {
                g_actorEnumMap[lowerCopy(label)] = enumValue;
                ++g_actorEnumRowsLoaded;
            }
            continue;
        }
    }

    g_dirtyActorMap = false;
    writeLog("Actor enum map loaded: rows=%zu aliases=%zu path=%s",
             g_actorEnumRowsLoaded, g_actorEnumMap.size(),
             g_actorEnumMapPath.c_str());
}

static void ensureDefaultActions() {
    if (!g_actions.empty()) return;
    g_actions = {
        "spawn_selected_npc_request",
        "follow_player_request",
        "guard_position_request",
        "defend_player_request",
        "attack_nearest_hostile_request",
        "idle_spawned_request",
        "wander_spawned_request",
        "regroup_near_player_request",
        "make_spawned_lawmen_request",
        "side_lawman_immunity_request",
        "side_gang_immunity_request",
        "restore_player_faction_request",
        "dismiss_ai_guest_request",
        "status_request"
    };
}

static bool csvEnabledValue(const std::string& value) {
    std::string clean = lowerCopy(trim(value));
    return clean.empty() || clean == "1" || clean == "true" || clean == "yes" ||
           clean == "on" || clean == "enabled";
}

static void loadActions() {
    loadConfig();
    std::vector<std::string> loaded;
    std::unordered_map<std::string, std::string> labels;

    std::ifstream file(g_actionsPath.c_str());
    if (!file) {
        g_dirtyActions = false;
        ensureDefaultActions();
        writeLog("Behavior action menu not found: %s", g_actionsPath.c_str());
        return;
    }

    std::string line;
    while (std::getline(file, line)) {
        std::string clean = trim(stripInlineComment(line));
        if (clean.empty()) continue;
        std::vector<std::string> fields = splitCsvLine(clean);
        if (fields.empty()) continue;

        std::string action = trim(fields[0]);
        if (action.empty()) continue;
        if (lowerCopy(action) == "action" || lowerCopy(action) == "id") continue;

        std::string enabled = fields.size() >= 4 ? fields[3] : "";
        if (!csvEnabledValue(enabled)) continue;

        loaded.push_back(action);
        if (fields.size() >= 2 && !trim(fields[1]).empty()) {
            labels[action] = trim(fields[1]);
        }
    }

    if (!loaded.empty()) {
        g_actions.swap(loaded);
        g_actionLabels.swap(labels);
    } else {
        ensureDefaultActions();
    }
    if (g_menuIndex < 0) g_menuIndex = 0;
    if (g_menuIndex >= static_cast<int>(g_actions.size())) g_menuIndex = 0;
    g_dirtyActions = false;
    writeLog("Behavior action menu loaded: count=%zu path=%s",
             g_actions.size(), g_actionsPath.c_str());
}

static void ensureDefaultRoster() {
    if (!g_roster.empty()) return;
    g_roster = {
        "amb_fh_farmer06",
        "amb_cowboy",
        "amb_worker",
        "gent_default",
        "gped_default",
        "player_bandito",
        "player_lawman",
        "player_marston",
        "law_sheriff",
        "misc_rancher",
        "com_companion",
        "crm_outlaw"
    };
}

static void loadRoster() {
    loadConfig();
    if (g_dirtyActorMap) loadActorEnumMap();

    g_roster.clear();
    std::ifstream file(g_rosterPath.c_str());
    std::string line;
    while (std::getline(file, line)) {
        std::string clean = trim(stripInlineComment(line));
        if (clean.empty()) continue;
        std::string label = displayRosterName(clean);
        if (label.empty()) continue;
        g_roster.push_back(clean);
    }
    ensureDefaultRoster();
    if (g_npcIndex < 0) g_npcIndex = 0;
    if (g_npcIndex >= static_cast<int>(g_roster.size())) g_npcIndex = 0;
    g_status = "Roster loaded: " + std::to_string(g_roster.size()) +
               " | enum rows: " + std::to_string(g_actorEnumRowsLoaded);
    g_dirtyRoster = false;
    writeLog("Roster loaded: count=%zu path=%s", g_roster.size(),
             g_rosterPath.c_str());
}

static std::string selectedNpcRaw() {
    ensureDefaultRoster();
    if (g_npcIndex < 0) g_npcIndex = 0;
    if (g_npcIndex >= static_cast<int>(g_roster.size())) g_npcIndex = 0;
    return g_roster[g_npcIndex];
}

static std::string selectedNpc() {
    return displayRosterName(selectedNpcRaw());
}

static std::string selectedAction() {
    ensureDefaultActions();
    if (g_menuIndex < 0) g_menuIndex = 0;
    if (g_menuIndex >= static_cast<int>(g_actions.size())) g_menuIndex = 0;
    return g_actions[g_menuIndex];
}

static void writeActionPlan();

static std::string displayAction(const std::string& action) {
    auto found = g_actionLabels.find(action);
    if (found != g_actionLabels.end() && !found->second.empty()) {
        return found->second;
    }

    std::string text = action;
    const std::string suffix = "_request";
    if (text.size() > suffix.size() &&
        text.compare(text.size() - suffix.size(), suffix.size(), suffix) == 0) {
        text.erase(text.size() - suffix.size());
    }
    std::replace(text.begin(), text.end(), '_', ' ');
    return text;
}

static bool parseInteger(const std::string& text, int* value) {
    if (!value) return false;
    char* end = nullptr;
    long parsed = std::strtol(text.c_str(), &end, 0);
    if (end == text.c_str() || *end != '\0') return false;
    *value = static_cast<int>(parsed);
    return true;
}

static int actorEnumFromRosterLine(const std::string& line) {
    if (!nativeReady()) return 0;

    std::vector<std::string> candidates;
    candidates.push_back(displayRosterName(line));
    candidates.push_back(trim(stripInlineComment(line)));

    size_t delimiter = line.find('|');
    if (delimiter == std::string::npos) delimiter = line.find(',');
    if (delimiter == std::string::npos) delimiter = line.find('=');
    if (delimiter != std::string::npos) {
        candidates.push_back(trim(line.substr(0, delimiter)));
        candidates.push_back(trim(line.substr(delimiter + 1)));
    }

    for (const std::string& candidate : candidates) {
        if (candidate.empty()) continue;

        int numeric = 0;
        if (parseInteger(candidate, &numeric) && numeric > 0) {
            return numeric;
        }

        int actorEnum = nativeInvoke<int>(0xC739D1D2, candidate.c_str());
        if (actorEnum > 0) {
            return actorEnum;
        }
    }

    return 0;
}

static int selectedActorEnum() {
    if (g_dirtyActorMap) loadActorEnumMap();

    const std::string raw = selectedNpcRaw();
    if (g_actorEnumCacheValid && raw == g_actorEnumCacheRaw) {
        return g_actorEnumCacheValue;
    }

    int actorEnum = 0;
    if (resolveInlineActorEnum(raw, actorEnum)) {
        g_actorEnumCacheRaw = raw;
        g_actorEnumCacheValue = actorEnum;
        g_actorEnumCacheValid = true;
        return g_actorEnumCacheValue;
    }

    auto found = g_actorEnumMap.find(lowerCopy(selectedNpc()));
    if (found != g_actorEnumMap.end()) {
        g_actorEnumCacheRaw = raw;
        g_actorEnumCacheValue = found->second;
        g_actorEnumCacheValid = true;
        return g_actorEnumCacheValue;
    }

    // Preserve the current native bridge behavior for direct actor enum strings.
    g_actorEnumCacheRaw = raw;
    g_actorEnumCacheValue = actorEnumFromRosterLine(raw);
    g_actorEnumCacheValid = true;
    return g_actorEnumCacheValue;
}

static Layout ensureLayout() {
    if (!nativeReady()) return 0;
    if (g_layout > 0) return g_layout;

    g_layout = nativeInvoke<Layout>(0x5699DE7E, "CodeRED_AI_Menu_Layout");
    if (g_layout <= 0) {
        g_layout = nativeInvoke<Layout>(0x6CA53214, "CodeRED_AI_Menu_Layout");
    }
    return g_layout;
}

static void pruneSpawnedActors() {
    if (!nativeReady()) return;
    std::vector<Actor> alive;
    for (Actor actor : g_spawnedActors) {
        if (actor > 0 && nativeInvoke<BOOL>(0xBA6C3E92, actor)) {
            alive.push_back(actor);
        }
    }
    g_spawnedActors.swap(alive);
}

static Actor playerActor() {
    if (!nativeReady()) return 0;
    Actor player = nativeInvoke<Actor>(0xE8CFDD53, 0);
    if (player <= 0 || !nativeInvoke<BOOL>(0xBA6C3E92, player)) {
        return 0;
    }
    return player;
}

static bool isCodeRedSpawnedActor(Actor actor) {
    for (Actor spawned : g_spawnedActors) {
        if (spawned == actor) return true;
    }
    return false;
}

static float distanceSquared(const Vector3& a, const Vector3& b) {
    const float dx = a.x - b.x;
    const float dy = a.y - b.y;
    const float dz = a.z - b.z;
    return dx * dx + dy * dy + dz * dz;
}

static bool actorPosition(Actor actor, Vector3* out) {
    if (!out || actor <= 0 || !nativeReady()) return false;
    if (!nativeInvoke<BOOL>(0xBA6C3E92, actor)) return false;
    *out = {};
    nativeInvoke<void>(0x99BD9D6F, actor, out);
    return true;
}

static void saveOriginalPlayerFaction(Actor player) {
    if (g_savedPlayerFaction || player <= 0 || !nativeReady()) return;
    g_originalPlayerFaction = nativeInvoke<int>(0x52E2A611, player);
    if (g_originalPlayerFaction <= 0) {
        g_originalPlayerFaction = FACTION_PLAYER;
    }
    g_savedPlayerFaction = true;
    writeLog("Saved original player faction: %d", g_originalPlayerFaction);
}

static void setPlayerFactionSide(int faction, const char* label) {
    Actor player = playerActor();
    if (player <= 0) {
        g_status = "Player actor not ready";
        writeLog("Faction side failed: player actor invalid label=%s", label);
        return;
    }
    saveOriginalPlayerFaction(player);
    nativeInvoke<void>(0xCC63951A, player, faction);
    g_playerSideFaction = faction;
    g_status = std::string("Player side: ") + label + " faction " +
               std::to_string(faction);
    writeLog("Player faction set: label=%s faction=%d", label, faction);
}

static void restorePlayerFaction() {
    Actor player = playerActor();
    if (player <= 0) {
        g_status = "Player actor not ready";
        return;
    }
    const int restoreFaction = g_savedPlayerFaction ? g_originalPlayerFaction : FACTION_PLAYER;
    nativeInvoke<void>(0xCC63951A, player, restoreFaction);
    g_playerSideFaction = restoreFaction;
    g_status = "Player faction restored: " + std::to_string(restoreFaction);
    writeLog("Player faction restored: faction=%d", restoreFaction);
}

static void configureSpawnedAsLawmen(bool followPlayer) {
    Actor player = playerActor();
    pruneSpawnedActors();
    if (g_spawnedActors.empty()) {
        g_status = "No spawned actors to set as lawmen";
        writeLog("Lawman configure skipped: no spawned actors");
        return;
    }

    for (Actor actor : g_spawnedActors) {
        nativeInvoke<void>(0xCC63951A, actor, FACTION_US_LAW);
        nativeInvoke<void>(0x4C94EB9E, actor, TRUE);
        if (followPlayer && player > 0) {
            nativeInvoke<void>(0x12F0911A, actor, player);
        }
    }
    g_status = "Spawned actors set to US law";
    writeLog("Configured %zu spawned actor(s) as US law", g_spawnedActors.size());
}

static Actor nearestHostileToPlayer(float maxDistance) {
    if (!nativeReady() || !g_worldGetAllActors) return 0;
    Actor player = playerActor();
    if (player <= 0) return 0;

    Vector3 playerPos = {};
    if (!actorPosition(player, &playerPos)) return 0;

    constexpr int MAX_ACTORS = 512;
    int actors[MAX_ACTORS] = {};
    const int count = g_worldGetAllActors(actors, MAX_ACTORS);
    const float maxDistanceSq = maxDistance * maxDistance;
    float bestDistanceSq = maxDistanceSq;
    Actor best = 0;

    for (int i = 0; i < count && i < MAX_ACTORS; ++i) {
        Actor candidate = actors[i];
        if (candidate <= 0 || candidate == player) continue;
        if (isCodeRedSpawnedActor(candidate)) continue;
        if (!nativeInvoke<BOOL>(0xBA6C3E92, candidate)) continue;

        const int hostileA = nativeInvoke<int>(0x9AB964F4, candidate, player);
        const int hostileB = nativeInvoke<int>(0x9AB964F4, player, candidate);
        if (!hostileA && !hostileB) continue;

        Vector3 pos = {};
        if (!actorPosition(candidate, &pos)) continue;
        const float distSq = distanceSquared(playerPos, pos);
        if (distSq < bestDistanceSq) {
            bestDistanceSq = distSq;
            best = candidate;
        }
    }

    return best;
}

static void attackNearestHostileWithSpawned() {
    pruneSpawnedActors();
    if (g_spawnedActors.empty()) {
        g_status = "No spawned actors";
        writeLog("Attack hostile skipped: no spawned actors");
        return;
    }

    Actor target = nearestHostileToPlayer(90.0f);
    if (target <= 0) {
        g_status = "No nearby hostile found";
        writeLog("Attack hostile skipped: no target");
        return;
    }

    for (Actor actor : g_spawnedActors) {
        nativeInvoke<void>(0x16876A25, actor);
        nativeInvoke<void>(0x1AE4B75B, actor, target);
    }
    g_status = "Attack target sent: " + std::to_string(target);
    writeLog("Attack hostile sent: target=%d actors=%zu", target,
             g_spawnedActors.size());
}

static bool spawnSelectedNpc() {
    if (!nativeReady()) {
        g_status = "Native bridge unavailable";
        writeLog("Spawn failed: native bridge unavailable");
        return false;
    }

    const std::string npc = selectedNpc();
    const int actorEnum = selectedActorEnum();
    if (actorEnum <= 0) {
        g_status = "No actor enum for: " + npc;
        writeLog("Spawn failed: selected label did not resolve to an actor enum: %s",
                 npc.c_str());
        return false;
    }

    Actor player = playerActor();
    if (player <= 0) {
        g_status = "Player actor not ready";
        writeLog("Spawn failed: player actor was not valid");
        return false;
    }

    Layout layout = ensureLayout();
    if (layout <= 0) {
        g_status = "Could not create layout";
        writeLog("Spawn failed: CodeRED layout could not be found or created");
        return false;
    }

    Vector3 playerPos = {};
    nativeInvoke<void>(0x99BD9D6F, player, &playerPos);
    float heading = nativeInvoke<float>(0x42DE39F0, player);
    const float radians = heading * (PI / 180.0f);
    Vector2 spawnXY = {
        playerPos.x + std::sin(radians) * 2.0f,
        playerPos.y + std::cos(radians) * 2.0f
    };
    Vector2 orientXY = {0.0f, 1.0f};

    std::ostringstream instanceName;
    instanceName << "codered_ai_guest_" << ++g_spawnCounter;

    Actor spawned = nativeInvoke<Actor>(0x8D67F397, layout,
                                        instanceName.str().c_str(),
                                        actorEnum, spawnXY, playerPos.z,
                                        orientXY, heading);
    if (spawned <= 0 || !nativeInvoke<BOOL>(0xBA6C3E92, spawned)) {
        g_status = "Spawn native returned invalid actor";
        writeLog("Spawn failed: CREATE_ACTOR_IN_LAYOUT returned actor=%d enum=%d model=%s",
                 spawned, actorEnum, npc.c_str());
        return false;
    }

    g_spawnedActors.push_back(spawned);
    nativeInvoke<void>(0xECE8520B, spawned, heading, TRUE);
    nativeInvoke<void>(0x4C94EB9E, spawned, TRUE);
    nativeInvoke<void>(0x12F0911A, spawned, player);

    g_status = "Spawned actor " + std::to_string(spawned) + " enum " +
               std::to_string(actorEnum);
    writeLog("Spawn succeeded: actor=%d enum=%d model=%s", spawned, actorEnum,
             npc.c_str());
    return true;
}

static void commandSpawnedActors(const std::string& action) {
    if (!nativeReady()) {
        g_status = "Native bridge unavailable";
        writeLog("Action failed: native bridge unavailable action=%s",
                 action.c_str());
        return;
    }

    pruneSpawnedActors();
    if (g_spawnedActors.empty()) {
        g_status = "No CodeRED spawned actors";
        writeLog("Action skipped: no spawned actors action=%s", action.c_str());
        return;
    }

    Actor player = playerActor();
    if (player <= 0) {
        g_status = "Player actor not ready";
        writeLog("Action failed: player actor invalid action=%s", action.c_str());
        return;
    }

    if (action == "follow_player_request" ||
        action == "defend_player_request") {
        for (Actor actor : g_spawnedActors) {
            nativeInvoke<void>(0x4C94EB9E, actor, TRUE);
            nativeInvoke<void>(0x12F0911A, actor, player);
        }
        g_status = "Follow/defend sent to " +
                   std::to_string(g_spawnedActors.size()) + " actor(s)";
        writeLog("Follow/defend task sent to %zu actor(s)",
                 g_spawnedActors.size());
        return;
    }

    if (action == "guard_position_request" ||
        action == "idle_spawned_request") {
        for (Actor actor : g_spawnedActors) {
            nativeInvoke<void>(0x16876A25, actor);
            nativeInvoke<void>(0x6F80965D, actor, -1.0f, 0, 0);
        }
        g_status = "Stand guard sent to " +
                   std::to_string(g_spawnedActors.size()) + " actor(s)";
        writeLog("Stand guard task sent to %zu actor(s)",
                 g_spawnedActors.size());
        return;
    }

    if (action == "wander_spawned_request") {
        for (Actor actor : g_spawnedActors) {
            nativeInvoke<void>(0x16876A25, actor);
            nativeInvoke<void>(0x17BCA08E, actor, 0);
        }
        g_status = "Wander sent to " +
                   std::to_string(g_spawnedActors.size()) + " actor(s)";
        writeLog("Wander task sent to %zu actor(s)", g_spawnedActors.size());
        return;
    }

    if (action == "regroup_near_player_request") {
        for (Actor actor : g_spawnedActors) {
            nativeInvoke<void>(0x3EB7590C, actor, player, 2.0f, 4.0f);
        }
        g_status = "Regroup sent to " +
                   std::to_string(g_spawnedActors.size()) + " actor(s)";
        writeLog("Regroup task sent to %zu actor(s)", g_spawnedActors.size());
        return;
    }

    if (action == "dismiss_ai_guest_request") {
        for (Actor actor : g_spawnedActors) {
            nativeInvoke<void>(0x8BD21869, actor);
        }
        const size_t count = g_spawnedActors.size();
        g_spawnedActors.clear();
        g_status = "Dismissed " + std::to_string(count) + " actor(s)";
        writeLog("Dismissed %zu spawned actor(s)", count);
        return;
    }

    if (action == "make_spawned_lawmen_request") {
        configureSpawnedAsLawmen(true);
        return;
    }

    if (action == "attack_nearest_hostile_request") {
        attackNearestHostileWithSpawned();
        return;
    }

    g_status = "Unsupported action: " + displayAction(action);
    writeLog("Unsupported behavior action: %s", action.c_str());
}

static void executeSelectedAction() {
    const std::string action = selectedAction();
    writeActionPlan();

    if (!resolveNativeBridge(false)) {
        g_status = "Queued JSON; native bridge unavailable";
        writeLog("Native bridge unavailable while executing action=%s",
                 action.c_str());
        return;
    }

    if (action == "spawn_selected_npc_request") {
        spawnSelectedNpc();
    } else if (action == "side_lawman_immunity_request") {
        setPlayerFactionSide(FACTION_US_LAW, "US lawman");
    } else if (action == "side_gang_immunity_request") {
        setPlayerFactionSide(FACTION_GENERIC_CRIMINAL, "generic criminal/gang");
    } else if (action == "restore_player_faction_request") {
        restorePlayerFaction();
    } else if (action == "status_request") {
        pruneSpawnedActors();
        const int actorEnum = selectedActorEnum();
        g_status = "Native OK | enum " + std::to_string(actorEnum) +
                   " | spawned " + std::to_string(g_spawnedActors.size());
        writeLog("Status: native=ready selected=%s enum=%d spawned=%zu worldGetAllActors=%s playerSideFaction=%d",
                 selectedNpc().c_str(), actorEnum, g_spawnedActors.size(),
                 g_worldGetAllActors ? "ready" : "missing",
                 g_playerSideFaction);
    } else {
        commandSpawnedActors(action);
    }
}

static void writeActionPlan() {
    CreateDirectoryA("scratch", nullptr);

    std::ofstream file(g_actionPlanPath.c_str(), std::ios::trunc);
    if (!file) {
        g_status = "Could not write action plan";
        return;
    }

    std::time_t now = std::time(nullptr);
    const int actorEnum = selectedActorEnum();
    const bool actorEnumResolved = actorEnum > 0;

    file << "{\n";
    file << "  \"source\": \"CodeRED_AI_Menu\",\n";
    file << "  \"action\": \"" << jsonEscape(selectedAction()) << "\",\n";
    file << "  \"model\": \"" << jsonEscape(selectedNpc()) << "\",\n";
    file << "  \"actor_enum_resolved\": " << (actorEnumResolved ? "true" : "false") << ",\n";
    if (actorEnumResolved) {
        file << "  \"actor_enum\": " << actorEnum << ",\n";
        file << "  \"actor_enum_hex\": \"" << enumHex(actorEnum) << "\",\n";
    } else {
        file << "  \"actor_enum\": null,\n";
        file << "  \"actor_enum_hex\": null,\n";
    }
    file << "  \"spawned_actor_count\": " << g_spawnedActors.size() << ",\n";
    file << "  \"player_side_faction\": " << g_playerSideFaction << ",\n";
    file << "  \"status\": \"queued\",\n";
    file << "  \"timestamp\": " << static_cast<long long>(now) << "\n";
    file << "}\n";

    const std::string action = selectedAction();
    const std::string npc = selectedNpc();
    if (actorEnumResolved) {
        g_status = "Queued: " + action + " / " + npc + " enum " +
                   std::to_string(actorEnum);
        writeLog("Action plan written: action=%s model=%s enum=%d",
                 action.c_str(), npc.c_str(), actorEnum);
    } else {
        g_status = "Queued unresolved: add enum for " + npc;
        writeLog("Action plan written unresolved: action=%s model=%s",
                 action.c_str(), npc.c_str());
    }
}

static bool throttleKey() {
    DWORD now = GetTickCount();
    if (now - g_lastKeyMs < 140) return true;
    g_lastKeyMs = now;
    return false;
}

static void onKey(DWORD key, WORD repeats, BYTE scanCode, BOOL isExtended,
                  BOOL isWithAlt, BOOL wasDownBefore, BOOL isUpNow) {
    (void)repeats;
    (void)scanCode;
    (void)isExtended;
    (void)isWithAlt;

    if (isUpNow) return;
    if (wasDownBefore && key != VK_RETURN) return;

    if (key == VK_F8 || key == VK_INSERT) {
        if (throttleKey()) return;
        g_menuOpen = !g_menuOpen;
        if (g_menuOpen) {
            g_dirtyRoster = true;
            g_dirtyActorMap = true;
            g_dirtyActions = true;
        }
        writeLog("Menu toggled: open=%s key=0x%08lX",
                 g_menuOpen ? "true" : "false", key);
        return;
    }

    if (!g_menuOpen) return;
    if (throttleKey()) return;

    if (key == VK_BACK || key == VK_ESCAPE) {
        g_menuOpen = false;
        return;
    }

    if (key == VK_UP) {
        g_menuIndex--;
        if (g_menuIndex < 0) g_menuIndex = static_cast<int>(g_actions.size()) - 1;
        return;
    }

    if (key == VK_DOWN) {
        g_menuIndex++;
        if (g_menuIndex >= static_cast<int>(g_actions.size())) g_menuIndex = 0;
        return;
    }

    if (key == VK_LEFT) {
        ensureDefaultRoster();
        const bool fast = (GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0;
        g_npcIndex -= fast ? 10 : 1;
        if (g_npcIndex < 0) g_npcIndex = static_cast<int>(g_roster.size()) - 1;
        return;
    }

    if (key == VK_RIGHT) {
        ensureDefaultRoster();
        const bool fast = (GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0;
        g_npcIndex += fast ? 10 : 1;
        if (g_npcIndex >= static_cast<int>(g_roster.size())) g_npcIndex = 0;
        return;
    }

    if (key == VK_HOME) {
        g_npcIndex = 0;
        return;
    }

    if (key == VK_END) {
        ensureDefaultRoster();
        g_npcIndex = static_cast<int>(g_roster.size()) - 1;
        return;
    }

    if (key == VK_RETURN) {
        executeSelectedAction();
        return;
    }

    if (key == VK_F5) {
        g_dirtyRoster = true;
        g_dirtyActorMap = true;
        g_dirtyActions = true;
        g_status = "Reload requested";
        writeLog("Manual reload requested");
        return;
    }
}

static void drawLine(float x, float y, const std::string& text, int r = 235, int g = 235, int b = 235, float size = 0.018f) {
    drawTextSafe(x, y, text.c_str(), r, g, b, 255, FONT_REDEMPTION, size, JUSTIFY_LEFT);
}

static int crMinInt(int a, int b) { return a < b ? a : b; }
static int crMaxInt(int a, int b) { return a > b ? a : b; }
static float crMinFloat(float a, float b) { return a < b ? a : b; }
static float crMaxFloat(float a, float b) { return a > b ? a : b; }

static int listStartFor(int selected, int total, int visible) {
    if (total <= visible || visible <= 0) return 0;
    int start = selected - visible / 2;
    if (start < 0) start = 0;
    if (start > total - visible) start = total - visible;
    return start;
}

static void drawMenu() {
    if (!g_menuOpen) return;
    if (g_dirtyRoster) loadRoster();
    if (g_dirtyActorMap) loadActorEnumMap();
    if (g_dirtyActions) loadActions();

    const int totalActions = static_cast<int>(g_actions.size());
    const int totalRoster = static_cast<int>(g_roster.size());
    const int visibleActions = crMinInt(crMaxInt(totalActions, 1), 7);
    const int visibleRoster = crMinInt(crMaxInt(totalRoster, 1), 9);
    const int visibleRows = crMaxInt(visibleActions, visibleRoster);

    const float rowH = 0.026f;
    const float headerH = 0.120f;
    const float footerH = 0.070f;
    const float panelW = 0.520f;
    const float panelH = crMinFloat(0.780f, crMaxFloat(0.320f, headerH + footerH + rowH * static_cast<float>(visibleRows + 2)));
    const float x = 0.500f;
    const float y = 0.500f;
    const float left = x - panelW * 0.5f;
    const float top = y - panelH * 0.5f;

    drawRectSafe(x, y, panelW, panelH, 8, 8, 10, 205, 0.015f);
    drawRectSafe(x, top + 0.036f, panelW, 0.072f, 120, 0, 0, 220, 0.015f);
    drawRectSafe(x, top + panelH - 0.030f, panelW, 0.060f, 30, 0, 0, 190, 0.010f);

    drawTextSafe(left + 0.020f, top + 0.017f, "CodeRED AI Menu", 255, 235, 235, 255, FONT_REDEMPTION, 0.030f, JUSTIFY_LEFT);

    const std::string npc = selectedNpc();
    const int actorEnum = selectedActorEnum();
    std::string npcLine = "NPC: " + npc;
    std::string enumLine = "ENUM: " + std::to_string(actorEnum) + " / " + enumHex(actorEnum);
    drawTextSafe(left + 0.020f, top + 0.060f, npcLine.c_str(), 245, 245, 245, 245, FONT_REDEMPTION, 0.020f, JUSTIFY_LEFT);
    drawTextSafe(left + 0.020f, top + 0.085f, enumLine.c_str(), actorEnum > 0 ? 170 : 255, actorEnum > 0 ? 230 : 80, actorEnum > 0 ? 170 : 80, 245, FONT_REDEMPTION, 0.018f, JUSTIFY_LEFT);

    const float listTop = top + 0.130f;
    const float actionX = left + 0.025f;
    const float rosterX = left + panelW * 0.510f;
    const float colW = panelW * 0.455f;

    drawTextSafe(actionX, listTop - 0.030f, "Actions", 255, 80, 80, 255, FONT_REDEMPTION, 0.020f, JUSTIFY_LEFT);
    drawTextSafe(rosterX, listTop - 0.030f, "Roster", 255, 80, 80, 255, FONT_REDEMPTION, 0.020f, JUSTIFY_LEFT);

    const int actionStart = listStartFor(g_menuIndex, totalActions, visibleActions);
    for (int i = 0; i < visibleActions && actionStart + i < totalActions; ++i) {
        const int index = actionStart + i;
        const bool selected = index == g_menuIndex;
        const float rowY = listTop + rowH * static_cast<float>(i);
        if (selected) drawRectSafe(actionX + colW * 0.5f, rowY + 0.010f, colW, rowH, 95, 0, 0, 185, 0.006f);
        std::string label = (selected ? "> " : "  ") + displayAction(g_actions[index]);
        drawTextSafe(actionX + 0.005f, rowY, label.c_str(), selected ? 255 : 220, selected ? 245 : 210, selected ? 210 : 210, 255, FONT_REDEMPTION, 0.017f, JUSTIFY_LEFT);
    }

    const int rosterStart = listStartFor(g_npcIndex, totalRoster, visibleRoster);
    for (int i = 0; i < visibleRoster && rosterStart + i < totalRoster; ++i) {
        const int index = rosterStart + i;
        const bool selected = index == g_npcIndex;
        const float rowY = listTop + rowH * static_cast<float>(i);
        if (selected) drawRectSafe(rosterX + colW * 0.5f, rowY + 0.010f, colW, rowH, 70, 0, 0, 175, 0.006f);
        std::string label = (selected ? "> " : "  ") + displayRosterName(g_roster[index]);
        if (label.size() > 44) label = label.substr(0, 41) + "...";
        drawTextSafe(rosterX + 0.005f, rowY, label.c_str(), selected ? 255 : 220, selected ? 245 : 210, selected ? 210 : 210, 255, FONT_REDEMPTION, 0.017f, JUSTIFY_LEFT);
    }

    if (totalActions > visibleActions) {
        const int actionEnd = crMinInt(actionStart + visibleActions, totalActions);
        std::string hint = "actions " + std::to_string(actionStart + 1) + "-" + std::to_string(actionEnd) + " / " + std::to_string(totalActions);
        drawTextSafe(actionX + 0.005f, top + panelH - 0.050f, hint.c_str(), 190, 190, 190, 230, FONT_REDEMPTION, 0.015f, JUSTIFY_LEFT);
    }
    if (totalRoster > visibleRoster) {
        const int rosterEnd = crMinInt(rosterStart + visibleRoster, totalRoster);
        std::string hint = "roster " + std::to_string(rosterStart + 1) + "-" + std::to_string(rosterEnd) + " / " + std::to_string(totalRoster);
        drawTextSafe(rosterX + 0.005f, top + panelH - 0.050f, hint.c_str(), 190, 190, 190, 230, FONT_REDEMPTION, 0.015f, JUSTIFY_LEFT);
    }

    std::string footer = "F8 close | UP/DOWN action | LEFT/RIGHT roster | SHIFT+LEFT/RIGHT x10 | ENTER run";
    drawTextSafe(left + 0.020f, top + panelH - 0.026f, footer.c_str(), 235, 235, 235, 235, FONT_REDEMPTION, 0.015f, JUSTIFY_LEFT);
    if (!g_status.empty()) {
        drawTextSafe(left + 0.020f, top + panelH - 0.005f, g_status.c_str(), 255, 140, 140, 235, FONT_REDEMPTION, 0.014f, JUSTIFY_LEFT);
    }
}
// CodeRED compact scrolling menu layout pass v2 no-std-minmax



static void mainLoop() {
    while (true) {
        drawMenu();
        waitFrame(0);
    }
}

static DWORD WINAPI registrationThread(LPVOID param) {
    HMODULE module = reinterpret_cast<HMODULE>(param);
    writeLog("Registration worker started");
    loadConfig();

    const ULONGLONG deadline = GetTickCount64() + 30000;
    bool loggedDllMissing = false;
    bool loggedDllFound = false;
    bool loggedMissingExports = false;

    while (!InterlockedCompareExchange(&g_stopRequested, 0, 0) &&
           GetTickCount64() <= deadline) {
        const bool resolved = resolveScriptHook(!loggedMissingExports);

        if (!g_scriptHook) {
            if (!loggedDllMissing) {
                writeLog("ScriptHookRDR.dll not found yet");
                loggedDllMissing = true;
            }
        } else if (!loggedDllFound) {
            writeLog("ScriptHookRDR.dll found");
            loggedDllFound = true;
        }

        if (g_scriptHook && !resolved && !loggedMissingExports) {
            loggedMissingExports = true;
        }

        if (resolved) {
            if (resolveNativeBridge(true)) {
                writeLog("Native bridge ready");
            } else {
                writeLog("Native bridge unavailable; menu will still write action plans");
            }
            g_scriptRegister(module, codered::mainLoop);
            g_keyboardHandlerRegister(codered::onKey);
            InterlockedExchange(&g_registered, 1);
            writeLog("Registration succeeded");
            return 0;
        }

        Sleep(500);
    }

    if (InterlockedCompareExchange(&g_stopRequested, 0, 0)) {
        writeLog("Registration worker stopped before registration");
    } else {
        resolveScriptHook(true);
        writeLog("Registration failed: ScriptHookRDR exports were not ready within 30 seconds");
    }
    return 1;
}

} // namespace codered

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(module);
        codered::g_module = module;
        InterlockedExchange(&codered::g_stopRequested, 0);
        codered::writeLog("ASI attached");
        HANDLE thread = CreateThread(nullptr, 0, codered::registrationThread,
                                     module, 0, nullptr);
        if (thread) {
            CloseHandle(thread);
        } else {
            codered::writeLog("Registration worker creation failed: %lu",
                              GetLastError());
        }
    } else if (reason == DLL_PROCESS_DETACH) {
        InterlockedExchange(&codered::g_stopRequested, 1);
        codered::writeLog("ASI detach requested");
        if (InterlockedCompareExchange(&codered::g_registered, 0, 0) &&
            codered::g_keyboardHandlerUnregister) {
            codered::g_keyboardHandlerUnregister(codered::onKey);
            codered::writeLog("Keyboard handler unregistered");
        }
        if (InterlockedCompareExchange(&codered::g_registered, 0, 0) &&
            codered::g_scriptUnregister) {
            codered::g_scriptUnregister(module);
            codered::writeLog("Script unregistered");
        }
        InterlockedExchange(&codered::g_registered, 0);
        codered::writeLog("ASI detached");
    }
    return TRUE;
}
