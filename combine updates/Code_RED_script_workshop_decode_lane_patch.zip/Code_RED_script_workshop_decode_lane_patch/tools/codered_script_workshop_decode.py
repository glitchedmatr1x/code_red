#!/usr/bin/env python3
"""Code RED Script Workshop decode/merge validation lane.

This lane pulls Script Lab / Script Workshop capability into the one-app flow:
- full-decodes compile-lab source/include/build scripts
- full-reads loose compiled script resources (.wsc/.csc/.xsc/.sco/.ysc)
- mines readable strings and native/hash-like tokens from binary script resources
- optionally scans staged RPF archives for script entries and full-reads those entries
- writes an editable/read-only manifest so the main app knows what can be safely edited

It is read-only. It does not compile, patch, or overwrite source archives.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import subprocess
import sys
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Iterable, Sequence

VERSION = "1.0.0-script-workshop-decode-merge"

SCRIPT_LAB = Path("related_apps/code_red_sccl_attempt_bundle_v1/code_red_script_compile_lab_v1")
BUILD_KIT = Path("related_apps/code_red_sccl_attempt_bundle_v1/code_red_sccl_windows_build_kit_v1")
VALIDATOR = SCRIPT_LAB / "scripts/validate_vehicle_menu_probe.py"

TEXT_SUFFIXES = {
    ".c", ".h", ".hpp", ".cpp", ".py", ".bat", ".cmd", ".ps1", ".txt", ".md",
    ".xml", ".ini", ".cfg", ".csv", ".json", ".log",
}
COMPILED_SCRIPT_SUFFIXES = {".wsc", ".csc", ".xsc", ".sco", ".ysc"}
SOURCE_SCRIPT_SUFFIXES = {".c", ".h", ".py", ".bat", ".ps1", ".cmd"}
DEFAULT_SCAN_DIRS = (
    SCRIPT_LAB,
    BUILD_KIT,
    Path("docs"),
    Path("related_apps/CodeRED_Tuner/Mods"),
    Path("research/menu resources"),
)
DEFAULT_ARCHIVE_NAMES = ("content.rpf", "tune_d11generic.rpf")
MAX_LOOSE_SCRIPT_FILES = 400
MAX_ARCHIVE_SCRIPT_ENTRIES = 250

HASH_RE = re.compile(r"0x[0-9A-Fa-f]{8,16}")
NATIVE_NAME_RE = re.compile(r"\b[A-Z][A-Z0-9_]{3,}\b")
ASCII_STRING_RE = re.compile(rb"[\x20-\x7E]{4,}")


@dataclass
class ScriptFileRow:
    path: str
    source: str
    kind: str
    suffix: str
    size: int
    sha1: str
    decode_ok: bool
    encoding: str = ""
    line_count: int = 0
    editable: bool = False
    action: str = ""
    token_count: int = 0
    native_name_hits: int = 0
    hash_hits: int = 0
    string_count: int = 0
    warnings: list[str] = field(default_factory=list)


@dataclass
class Report:
    version: str
    generated_utc: str
    ok: bool
    root: str
    lab_root: str
    validator_exit_code: int | None
    files_total: int
    text_files: int
    binary_script_files: int
    archive_script_entries: int
    full_decode_ok: int
    full_decode_failed: int
    editable_files: int
    read_only_files: int
    native_name_hits: int
    hash_hits: int
    string_hits: int
    categories: dict[str, int]
    outputs: dict[str, str]
    warnings: list[str]


def utc_now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z")


def sha1_bytes(data: bytes) -> str:
    return hashlib.sha1(data).hexdigest()


def decode_text_full(data: bytes) -> tuple[bool, str, str, int]:
    if not data:
        return True, "utf-8", "", 0
    encodings: list[str] = []
    if data.startswith(b"\xef\xbb\xbf"):
        encodings.append("utf-8-sig")
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        encodings.extend(["utf-16", "utf-16-le", "utf-16-be"])
    encodings.extend(["utf-8", "cp1252", "latin-1"])
    seen: set[str] = set()
    for enc in encodings:
        if enc in seen:
            continue
        seen.add(enc)
        try:
            text = data.decode(enc)
            return True, enc, text, len(text.splitlines())
        except UnicodeDecodeError:
            continue
    text = data.decode("utf-8", errors="replace")
    return False, "utf-8-replace", text, len(text.splitlines())


def import_workbench(root: Path):
    sys.path.insert(0, str(root))
    import python_workbench as wb  # type: ignore
    return wb


def binary_string_count(data: bytes) -> int:
    return len(ASCII_STRING_RE.findall(data))


def mine_text_tokens(text: str) -> tuple[int, int, int]:
    names = [m.group(0) for m in NATIVE_NAME_RE.finditer(text)]
    hashes = [m.group(0) for m in HASH_RE.finditer(text)]
    return len(set(names)), len(set(hashes)), len(names) + len(hashes)


def mine_binary_tokens(data: bytes) -> tuple[int, int, int, int]:
    strings = [s.decode("latin-1", errors="ignore") for s in ASCII_STRING_RE.findall(data)]
    joined = "\n".join(strings)
    native_hits, hash_hits, token_count = mine_text_tokens(joined)
    return native_hits, hash_hits, token_count, len(strings)


def classify_path(path: Path) -> tuple[str, bool, str]:
    suffix = path.suffix.lower()
    if suffix in TEXT_SUFFIXES:
        if suffix in {".c", ".h", ".hpp", ".cpp"}:
            return "script_source", True, "safe_text_edit_and_compile_probe"
        if suffix in {".py", ".bat", ".cmd", ".ps1"}:
            return "tooling_script", True, "safe_text_edit_tooling"
        return "text_support", True, "safe_text_edit"
    if suffix in COMPILED_SCRIPT_SUFFIXES:
        return "compiled_script_binary", False, "full_read_string_mine_read_only"
    return "other", False, "full_read_only"


def inspect_loose_file(root: Path, path: Path) -> ScriptFileRow:
    data = path.read_bytes()
    suffix = path.suffix.lower()
    kind, editable, action = classify_path(path)
    rel = str(path.relative_to(root)) if path.is_relative_to(root) else str(path)
    row = ScriptFileRow(
        path=rel,
        source="loose",
        kind=kind,
        suffix=suffix,
        size=len(data),
        sha1=sha1_bytes(data),
        decode_ok=True,
        editable=editable,
        action=action,
    )
    if suffix in TEXT_SUFFIXES:
        ok, enc, text, lines = decode_text_full(data)
        row.decode_ok = ok
        row.encoding = enc
        row.line_count = lines
        row.native_name_hits, row.hash_hits, row.token_count = mine_text_tokens(text)
        if not ok:
            row.warnings.append("strict text decode failed; replacement fallback used")
    elif suffix in COMPILED_SCRIPT_SUFFIXES:
        row.native_name_hits, row.hash_hits, row.token_count, row.string_count = mine_binary_tokens(data)
    else:
        row.string_count = binary_string_count(data)
    return row


def discover_loose_files(root: Path) -> list[Path]:
    files: list[Path] = []
    seen: set[str] = set()
    wanted = TEXT_SUFFIXES | COMPILED_SCRIPT_SUFFIXES
    for rel_dir in DEFAULT_SCAN_DIRS:
        base = root / rel_dir
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if len(files) >= MAX_LOOSE_SCRIPT_FILES:
                break
            if not path.is_file() or path.suffix.lower() not in wanted:
                continue
            if any(part in {"__pycache__", ".git", ".vs", "build", "dist"} for part in path.parts):
                continue
            key = str(path.resolve())
            if key in seen:
                continue
            seen.add(key)
            files.append(path)
    return files


def discover_archives(root: Path, include_parent_sources: bool) -> list[Path]:
    bases = [root / "imports", root / "game", root]
    if include_parent_sources:
        bases.append(root.parent)
    out: list[Path] = []
    seen: set[str] = set()
    for base in bases:
        if not base.exists():
            continue
        for name in DEFAULT_ARCHIVE_NAMES:
            path = base / name
            if path.exists() and path.is_file():
                key = str(path.resolve())
                if key not in seen:
                    seen.add(key)
                    out.append(path)
    return out


def inspect_archive_scripts(root: Path, archive: Path) -> list[ScriptFileRow]:
    rows: list[ScriptFileRow] = []
    wb = import_workbench(root)
    info = wb.parse_rpf6(archive)
    if not info:
        return rows
    entries = [ent for ent in info.get("entries", []) if ent.get("type") == "file"]
    script_entries = [ent for ent in entries if str(ent.get("extension") or "").lower() in COMPILED_SCRIPT_SUFFIXES]
    for ent in script_entries[:MAX_ARCHIVE_SCRIPT_ENTRIES]:
        try:
            data = wb.extract_rpf_entry(archive, ent)
            native_hits, hash_hits, token_count, string_count = mine_binary_tokens(data)
            rows.append(ScriptFileRow(
                path=f"{archive.name}:{ent.get('path') or ent.get('name') or ent.get('index')}",
                source="archive",
                kind="compiled_script_binary",
                suffix=str(ent.get("extension") or "").lower(),
                size=len(data),
                sha1=sha1_bytes(data),
                decode_ok=True,
                editable=False,
                action="archive_full_read_string_mine_read_only",
                token_count=token_count,
                native_name_hits=native_hits,
                hash_hits=hash_hits,
                string_count=string_count,
            ))
        except Exception as exc:
            rows.append(ScriptFileRow(
                path=f"{archive.name}:{ent.get('path') or ent.get('name') or ent.get('index')}",
                source="archive",
                kind="compiled_script_binary",
                suffix=str(ent.get("extension") or "").lower(),
                size=0,
                sha1="",
                decode_ok=False,
                editable=False,
                action="archive_script_extract_failed",
                warnings=[str(exc)],
            ))
    return rows


def run_validator(root: Path) -> tuple[int | None, str]:
    script = root / VALIDATOR
    if not script.exists():
        return None, f"validator missing: {script}"
    try:
        proc = subprocess.run(
            [sys.executable, str(script)],
            cwd=str(root / SCRIPT_LAB),
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        text = "\n".join(part.strip() for part in (proc.stdout, proc.stderr) if part and part.strip())
        return proc.returncode, text
    except Exception as exc:
        return None, f"validator launch failed: {exc}"


def write_outputs(root: Path, rows: list[ScriptFileRow], report: Report) -> None:
    data_dir = root / "data" / "codered"
    logs_dir = root / "logs"
    data_dir.mkdir(parents=True, exist_ok=True)
    logs_dir.mkdir(parents=True, exist_ok=True)
    csv_path = data_dir / "script_workshop_decode_manifest.csv"
    json_path = data_dir / "script_workshop_decode_manifest.json"
    registry_path = data_dir / "script_workshop_capabilities.json"
    report_json = logs_dir / "CodeRED_Script_Workshop_Decode_Report.json"
    report_md = logs_dir / "CodeRED_Script_Workshop_Decode_Report.md"
    pass_log = logs_dir / "CodeRED_Script_Workshop_Decode_Lane_Pass_2026-05-03.md"

    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(asdict(rows[0]).keys()) if rows else list(ScriptFileRow("","","","",0,"",False).__dict__.keys()))
        writer.writeheader()
        for row in rows:
            data = asdict(row)
            data["warnings"] = " | ".join(row.warnings)
            writer.writerow(data)
    json_path.write_text(json.dumps([asdict(row) for row in rows], indent=2), encoding="utf-8")

    capabilities = {
        "version": VERSION,
        "generated_utc": report.generated_utc,
        "purpose": "Merged Script Lab / Script Workshop decode capabilities into Code RED one-app flow.",
        "safe_actions": [
            "edit_text_source",
            "validate_vehicle_menu_probe",
            "inspect_compiled_script_binary",
            "mine_binary_script_strings",
            "mine_native_names_and_hashes",
            "stage_windows_build_plan",
        ],
        "proof_gated_actions": [
            "compile_with_sccl_on_windows",
            "existing_wsc_binary_roundtrip",
            "semantic_bytecode_editing",
            "automatic_archive_reintegration",
        ],
        "manifest_csv": str(csv_path.relative_to(root)),
        "manifest_json": str(json_path.relative_to(root)),
    }
    registry_path.write_text(json.dumps(capabilities, indent=2), encoding="utf-8")

    report.outputs.update({
        "manifest_csv": str(csv_path),
        "manifest_json": str(json_path),
        "capabilities_json": str(registry_path),
        "report_json": str(report_json),
        "report_md": str(report_md),
        "pass_log": str(pass_log),
    })
    report_json.write_text(json.dumps(asdict(report), indent=2), encoding="utf-8")
    report_md.write_text(report_markdown(report), encoding="utf-8")
    pass_log.write_text(pass_log_markdown(report), encoding="utf-8")


def report_markdown(report: Report) -> str:
    lines = [
        "# Code RED Script Workshop Decode Report",
        "",
        f"Generated UTC: `{report.generated_utc}`",
        f"Result: **{'PASS' if report.ok else 'FAIL'}**",
        "",
        "## Summary",
        "",
        f"- Lab root: `{report.lab_root}`",
        f"- Vehicle-menu validator exit: `{report.validator_exit_code}`",
        f"- Files indexed: {report.files_total}",
        f"- Text/source files: {report.text_files}",
        f"- Loose binary scripts: {report.binary_script_files}",
        f"- Archive script entries: {report.archive_script_entries}",
        f"- Full decode/read OK: {report.full_decode_ok}",
        f"- Full decode/read failed: {report.full_decode_failed}",
        f"- Editable text files: {report.editable_files}",
        f"- Read-only files: {report.read_only_files}",
        f"- Native-name hits: {report.native_name_hits}",
        f"- Hash hits: {report.hash_hits}",
        f"- Binary/string hits: {report.string_hits}",
        "",
        "## Categories",
        "",
    ]
    for key, value in sorted(report.categories.items()):
        lines.append(f"- {key}: {value}")
    if report.warnings:
        lines.extend(["", "## Warnings", ""])
        lines.extend(f"- {warning}" for warning in report.warnings[:50])
    lines.extend([
        "",
        "## Outputs",
        "",
    ])
    for key, value in report.outputs.items():
        lines.append(f"- {key}: `{value}`")
    lines.extend([
        "",
        "## Honest Scope",
        "",
        "This proves full file reads, text/source decode, compiled-script binary reads, token mining, and Script Lab validator integration.",
        "It does not claim arbitrary existing `.wsc`/`.xsc`/`.sco` bytecode roundtrip or semantic bytecode editing is solved yet.",
    ])
    return "\n".join(lines) + "\n"


def pass_log_markdown(report: Report) -> str:
    return "\n".join([
        "# CodeRED Script Workshop Decode Lane Pass - 2026-05-03",
        "",
        "Merged Script Lab / Script Workshop decode capability into the Code RED one-app workflow.",
        "",
        "## Result",
        "",
        f"- PASS: {report.ok}",
        f"- Files indexed: {report.files_total}",
        f"- Full decode/read OK: {report.full_decode_ok}",
        f"- Full decode/read failed: {report.full_decode_failed}",
        f"- Editable text/source files: {report.editable_files}",
        f"- Read-only binary/archive files: {report.read_only_files}",
        "",
        "## What was merged",
        "",
        "- Script Lab source/include/build-script full decode.",
        "- Script Workshop-style compiled script binary full read/string mining.",
        "- Native/hash token mining for both text source and binary script resources.",
        "- Editable/read-only manifest for the main Code RED app.",
        "- Capabilities registry separating safe actions from proof-gated actions.",
        "",
        "## Not claimed yet",
        "",
        "- Existing binary `.wsc`/`.xsc`/`.sco` roundtrip.",
        "- Semantic bytecode editing.",
        "- Automatic RPF reintegration of edited scripts.",
        "",
    ]) + "\n"


def run(root: Path, include_parent_sources: bool) -> tuple[Report, list[ScriptFileRow]]:
    rows: list[ScriptFileRow] = []
    warnings: list[str] = []
    for path in discover_loose_files(root):
        try:
            rows.append(inspect_loose_file(root, path))
        except Exception as exc:
            rel = str(path.relative_to(root)) if path.is_relative_to(root) else str(path)
            rows.append(ScriptFileRow(rel, "loose", "unknown", path.suffix.lower(), 0, "", False, warnings=[str(exc)]))
    for archive in discover_archives(root, include_parent_sources=include_parent_sources):
        try:
            rows.extend(inspect_archive_scripts(root, archive))
        except Exception as exc:
            warnings.append(f"archive script scan failed for {archive}: {exc}")
    validator_exit, validator_text = run_validator(root)
    if validator_exit not in (0, None):
        warnings.append(f"vehicle-menu validator exited {validator_exit}: {validator_text[:500]}")
    categories = Counter(row.kind for row in rows)
    full_ok = sum(1 for row in rows if row.decode_ok)
    full_failed = sum(1 for row in rows if not row.decode_ok)
    text_files = sum(1 for row in rows if row.kind in {"script_source", "tooling_script", "text_support"})
    binary_files = sum(1 for row in rows if row.kind == "compiled_script_binary" and row.source == "loose")
    archive_entries = sum(1 for row in rows if row.source == "archive")
    editable = sum(1 for row in rows if row.editable)
    read_only = len(rows) - editable
    ok = bool(rows) and full_failed == 0 and (validator_exit in (0, None))
    if not (root / SCRIPT_LAB).exists():
        ok = False
        warnings.append(f"script lab missing: {root / SCRIPT_LAB}")
    report = Report(
        version=VERSION,
        generated_utc=utc_now(),
        ok=ok,
        root=str(root),
        lab_root=str(root / SCRIPT_LAB),
        validator_exit_code=validator_exit,
        files_total=len(rows),
        text_files=text_files,
        binary_script_files=binary_files,
        archive_script_entries=archive_entries,
        full_decode_ok=full_ok,
        full_decode_failed=full_failed,
        editable_files=editable,
        read_only_files=read_only,
        native_name_hits=sum(row.native_name_hits for row in rows),
        hash_hits=sum(row.hash_hits for row in rows),
        string_hits=sum(row.string_count for row in rows),
        categories=dict(sorted(categories.items())),
        outputs={},
        warnings=warnings + [warn for row in rows for warn in row.warnings[:3]][:50],
    )
    return report, rows


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Validate/merge Script Lab and Script Workshop decode capabilities into Code RED.")
    parser.add_argument("--root", default=".", help="Code RED root folder")
    parser.add_argument("--include-parent-sources", action="store_true", help="Also scan parent folder for staged content/tune RPF archives")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    root = Path(args.root).resolve()
    report, rows = run(root, include_parent_sources=args.include_parent_sources)
    write_outputs(root, rows, report)
    print(f"Script Workshop decode: {'PASS' if report.ok else 'FAIL'}")
    print(f"Files indexed: {report.files_total}")
    print(f"Full decode/read OK: {report.full_decode_ok}/{report.files_total}")
    print(f"Editable files: {report.editable_files}")
    print(f"Binary/archive read-only files: {report.read_only_files}")
    print(f"Report: {root / 'logs' / 'CodeRED_Script_Workshop_Decode_Report.md'}")
    return 0 if report.ok else 2


if __name__ == "__main__":
    raise SystemExit(main())
