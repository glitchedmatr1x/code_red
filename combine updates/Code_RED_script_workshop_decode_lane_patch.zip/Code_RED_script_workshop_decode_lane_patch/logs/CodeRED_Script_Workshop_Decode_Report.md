# Code RED Script Workshop Decode Report

Generated UTC: `2026-05-03T09:34:14Z`
Result: **PASS**

## Summary

- Lab root: `/mnt/data/codered_work/related_apps/code_red_sccl_attempt_bundle_v1/code_red_script_compile_lab_v1`
- Vehicle-menu validator exit: `0`
- Files indexed: 58
- Text/source files: 35
- Loose binary scripts: 23
- Archive script entries: 0
- Full decode/read OK: 58
- Full decode/read failed: 0
- Editable text files: 35
- Read-only files: 23
- Native-name hits: 6646
- Hash hits: 5053
- Binary/string hits: 4952

## Categories

- compiled_script_binary: 23
- script_source: 11
- text_support: 18
- tooling_script: 6

## Outputs

- manifest_csv: `/mnt/data/codered_work/data/codered/script_workshop_decode_manifest.csv`
- manifest_json: `/mnt/data/codered_work/data/codered/script_workshop_decode_manifest.json`
- capabilities_json: `/mnt/data/codered_work/data/codered/script_workshop_capabilities.json`
- report_json: `/mnt/data/codered_work/logs/CodeRED_Script_Workshop_Decode_Report.json`
- report_md: `/mnt/data/codered_work/logs/CodeRED_Script_Workshop_Decode_Report.md`
- pass_log: `/mnt/data/codered_work/logs/CodeRED_Script_Workshop_Decode_Lane_Pass_2026-05-03.md`

## Honest Scope

This proves full file reads, text/source decode, compiled-script binary reads, token mining, and Script Lab validator integration.
It does not claim arbitrary existing `.wsc`/`.xsc`/`.sco` bytecode roundtrip or semantic bytecode editing is solved yet.
