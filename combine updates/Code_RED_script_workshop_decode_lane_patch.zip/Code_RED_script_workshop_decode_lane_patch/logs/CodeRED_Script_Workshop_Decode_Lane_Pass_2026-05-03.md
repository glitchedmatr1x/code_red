# CodeRED Script Workshop Decode Lane Pass - 2026-05-03

Merged Script Lab / Script Workshop decode capability into the Code RED one-app workflow.

## Result

- PASS: True
- Files indexed: 58
- Full decode/read OK: 58
- Full decode/read failed: 0
- Editable text/source files: 35
- Read-only binary/archive files: 23

## What was merged

- Script Lab source/include/build-script full decode.
- Script Workshop-style compiled script binary full read/string mining.
- Native/hash token mining for both text source and binary script resources.
- Editable/read-only manifest for the main Code RED app.
- Capabilities registry separating safe actions from proof-gated actions.

## Not claimed yet

- Existing binary `.wsc`/`.xsc`/`.sco` roundtrip.
- Semantic bytecode editing.
- Automatic RPF reintegration of edited scripts.

