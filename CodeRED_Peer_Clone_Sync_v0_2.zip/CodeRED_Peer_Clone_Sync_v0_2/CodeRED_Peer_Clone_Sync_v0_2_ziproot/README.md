# Code RED Peer Clone Sync v0.2

Public test package for a two-PC Code RED clone-sync relay.

Read first: `READ_FIRST_PUBLIC_TEST.txt`

This package only proves connection/state relay. The next phase is the in-game bridge that spawns and moves the remote clone actor.
