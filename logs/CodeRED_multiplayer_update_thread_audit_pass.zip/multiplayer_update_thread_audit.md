# CodeRED Multiplayer Update Thread Audit

Subject: `content/release/multiplayer/multiplayer_update_thread.csc`

## Binary summary

- size: `24500`
- sha256: `b82d0afd1a9746238738e7b01680ddd5c2560ec36dbb095e8dce4852dce9dc5b`
- rsc_magic_le: `0x52534386`
- version_word_le: `0x2000000`
- header_size_word_le: `0x80`
- flags_word_le: `0xe000090`
- entropy: `7.9921`
- payload_entropy_after_0x80: `7.9921`
- printable_ratio: `0.3822`
- zero_ratio: `0.0042`
- string_count_n4: `272`

## Content.rpf presence check

- `multiplayer_update_thread`: `-1`
- `release/multiplayer`: `-1`
- `content/release/multiplayer/multiplayer_update_thread.csc`: `-1`
- exact slice `0x0`: `-1`
- exact slice `0x80`: `-1`
- exact slice `0x100`: `-1`
- exact slice `0x1000`: `-1`
- exact slice `0x2000`: `-1`
- exact slice `0x2fda`: `-1`

## Boot XML multiplayer markers

- `NetMachine.SetMultiplayerModeToLaunch`: `9`
- `NetMachine.SetFreeRoamMode`: `3`
- `NetMachine.Authenticate`: `9`
- `NetMachine.TriggerMultiplayerLoad`: `0`
- `Enter(LoadingScreen)`: `6`
- `net.EnterMultiplayerStartMenu`: `1`

## Conclusion

- **new_vs_current_content_rpf**: No plain filename/path hit and no exact byte-slice hit in uploaded content.rpf. This supports the user suspicion that this root/release multiplayer_update_thread.csc is not in the current content.rpf inventory we have been patching.
- **readability**: RSC CSC binary, high entropy; simple string/CodeRED scan cannot expose task names or natives from payload yet.
- **importance**: Likely a top-level multiplayer runtime/update thread from a root/release script tree, separate from the content.rpf UI/SCXML route that CodeRED previously researched.
- **safe_next_step**: Add it as a script-reader target and correlate against boot/taskmachine NetMachine routes before attempting any patch or replacement.

## Root package CSC comparison

- `0x379A8CE9` size `13` flags `None` entropy `3.2389`
- `content/0xC10D9746` size `4832` flags `0x3c20200a` entropy `5.1316`
- `content/release/main.csc` size `83457` flags `0x37000080` entropy `7.9977`
- `content/release/multiplayer/multiplayer_update_thread.csc` size `24500` flags `0xe000090` entropy `7.9921`
- `content/release/multiplayer/regions/coop/coopbasic.csc` size `9485` flags `0x5000080` entropy `7.9795`
- `content/release/scripting/designerdefined/medium_update_thread.csc` size `46876` flags `0x21000080` entropy `7.9957`
- `content/release/scripting/designerdefined/ui/0xAF15E412` size `8201` flags `0x5000080` entropy `7.9735`
- `content/release/scripting/designerdefined/ui/fuieventmonitor.csc` size `28252` flags `0x15000080` entropy `7.992`
- `content/release/scripting/mods/0xA9CDCA36` size `791` flags `0x1000080` entropy `7.7389`