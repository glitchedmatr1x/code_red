# Code RED Faction War — No-SC Menu-Free Pass 01

This is a continuation branch of `CodeRedFactionWarV26_ReadyProject` with the trainer/debug menu layer disabled.

## Purpose

The goal is to keep the faction-war world simulation alive as an ambient background layer instead of a menu-driven trainer. It is prepared for the newer Code RED direction: use editable tune/camera/content resources where possible, and avoid SC-CL for this branch.

## What changed from v26

- The F7 overlay/menu path is disabled.
- Numpad/F-key debug controls are disabled.
- HUD toast spam is disabled by default.
- Simulation remains enabled automatically.
- Save/log/diagnostic/bulletin filenames were moved to `CodeRedFactionWar_NoSC_MenuFree.*`.
- The v26 faction, node, pressure, heat, supply, fear, logistics, convoy, town-assault, regional-shootout, occupation, directive, bulletin, and auto-event systems are preserved.

## Important distinction

This branch is **non-SC-CL**. It does not use the SC-CL compile lane.

The included Visual Studio project is still a RedHook `.red` plugin project because that is what the original v26 runtime was. The new `WorldResourceBridge/` folder is the no-EXE/no-compiler research lane: it converts the same faction-war design into editable tune-style `.tr`, `.pop`, `.traffic`, and JSON patch data for Code RED’s internal resource workflow.

## Files to inspect first

- `Source/CodeRedFactionWar/code_red_factionwar_plugin_v26.cpp`
- `Source/CodeRedFactionWar/code_red_faction_seed_v26.inl`
- `Source/CodeRedFactionWar/code_red_tune_profiles_v26.inl`
- `WorldResourceBridge/factionwar_nodes.json`
- `WorldResourceBridge/tune_ai/code_red_factionwar_world.tr`
- `WorldResourceBridge/tune_level/code_red_factionwar_level.pop`
- `WorldResourceBridge/tune_settings/code_red_factionwar.traffic`

## Runtime behavior

The world layer should now quietly:

- Track nearest faction-war territory.
- Update region pressure and daily directives.
- Generate rumors/bulletins/logs.
- Trigger nearby auto-events through the existing v26 world logic.
- Save state without requiring the player to open a menu.

## Next Code RED pass

The next major step is to let Code RED inject or merge the `WorldResourceBridge` text resources into tune/content archives using the Zstandard decode/rebuild path already discovered in tune and camera RPF research.
