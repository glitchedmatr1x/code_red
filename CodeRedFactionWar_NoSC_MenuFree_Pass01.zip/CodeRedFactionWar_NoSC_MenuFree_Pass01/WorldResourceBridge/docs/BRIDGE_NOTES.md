# WorldResourceBridge Notes

This folder is the no-EXE/no-SC-CL lane for continuing Faction War.

It converts v26's hardcoded seed data into readable resource-side files that match the coding styles found in `tune_d11generic.rpf`:

- `.tr` AI rule-script style
- `.pop` population profile style
- `.traffic` route/traffic profile style
- JSON patch recipe for Code RED's future RPF merge workflow

These files are not meant to be blindly dropped into the game. They are merge targets for the next Code RED archive-editing pass after Zstandard decode/rebuild is wired into the workbench.
